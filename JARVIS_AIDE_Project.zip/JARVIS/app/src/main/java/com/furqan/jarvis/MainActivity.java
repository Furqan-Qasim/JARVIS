package com.furqan.jarvis;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

/**
 * MainActivity — The Holographic JARVIS Interface
 *
 * Full-screen dark holographic UI with:
 * - Three.js hologram in WebView (central floating glowing JARVIS form)
 * - Real-time audio waveform visualization
 * - State indicators (STANDBY / LISTENING / SPEAKING / PROCESSING)
 * - Quick action buttons (Text Mode, Build Mode, Settings)
 * - Live transcript overlay
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final int PERM_REQUEST = 100;

    private WebView hologramWebView;
    private TextView statusText;
    private TextView transcriptText;
    private ImageButton btnTextMode;
    private ImageButton btnBuildMode;
    private ImageButton btnSettings;
    private ImageButton btnCamera;
    private View waveformOverlay;

    private JarvisService jarvisService;
    private boolean serviceBound = false;
    private MemoryManager memory;

    // Broadcast receivers for service → UI updates
    private BroadcastReceiver stateReceiver;
    private BroadcastReceiver transcriptReceiver;
    private BroadcastReceiver audioLevelReceiver;

    private static final String[] REQUIRED_PERMISSIONS = {
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.WRITE_CONTACTS,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.CAMERA,
        Manifest.permission.POST_NOTIFICATIONS,
        Manifest.permission.READ_CALENDAR,
        Manifest.permission.WRITE_CALENDAR,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // True full-screen: hide status bar, keep screen on
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );

        setContentView(R.layout.activity_main);

        memory = MemoryManager.getInstance(this);

        initViews();
        setupWebView();
        setupButtons();
        setupBroadcastReceivers();

        // First launch: go to permissions / settings setup
        if (memory.isFirstLaunch()) {
            startActivity(new Intent(this, PermissionActivity.class));
            return;
        }

        checkAndRequestPermissions();
        startJarvisService();
    }

    // ─── View Initialization ─────────────────────────────────────────────

    private void initViews() {
        hologramWebView = findViewById(R.id.hologram_webview);
        statusText       = findViewById(R.id.status_text);
        transcriptText   = findViewById(R.id.transcript_text);
        btnTextMode      = findViewById(R.id.btn_text_mode);
        btnBuildMode     = findViewById(R.id.btn_build_mode);
        btnSettings      = findViewById(R.id.btn_settings);
        btnCamera        = findViewById(R.id.btn_camera);
        waveformOverlay  = findViewById(R.id.waveform_overlay);
    }

    // ─── WebView / Three.js Hologram ─────────────────────────────────────

    private void setupWebView() {
        WebSettings ws = hologramWebView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);

        // JavaScript bridge: Java → JS for state updates
        hologramWebView.addJavascriptInterface(new HologramBridge(), "AndroidBridge");

        hologramWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                // Set initial state
                setHologramState("STANDBY");
            }
        });

        hologramWebView.setBackgroundColor(0x00000000);
        hologramWebView.loadUrl("file:///android_asset/hologram.html");
    }

    /**
     * JavaScript bridge — allows hologram.html to call Java methods
     */
    private class HologramBridge {
        @JavascriptInterface
        public void onHologramTapped() {
            Log.d(TAG, "Hologram tapped");
            runOnUiThread(() -> {
                if (jarvisService != null) {
                    if (jarvisService.getServiceState() == JarvisService.State.STANDBY) {
                        jarvisService.activateJarvis();
                    } else {
                        jarvisService.deactivateJarvis();
                    }
                }
            });
        }

        @JavascriptInterface
        public void log(String message) {
            Log.d("HologramJS", message);
        }
    }

    private void setHologramState(String state) {
        hologramWebView.post(() ->
            hologramWebView.evaluateJavascript(
                "setJarvisState('" + state + "')", null));
    }

    private void setHologramAudioLevel(float level) {
        hologramWebView.post(() ->
            hologramWebView.evaluateJavascript(
                "setAudioLevel(" + level + ")", null));
    }

    // ─── Buttons ─────────────────────────────────────────────────────────

    private void setupButtons() {
        btnTextMode.setOnClickListener(v -> {
            startActivity(new Intent(this, TextModeActivity.class));
        });

        btnBuildMode.setOnClickListener(v -> {
            startActivity(new Intent(this, BuildModeActivity.class));
        });

        btnCamera.setOnClickListener(v -> {
            Intent cam = new Intent(this, FloatingCameraService.class);
            cam.setAction("START_CAMERA");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(cam);
            } else {
                startService(cam);
            }
            Toast.makeText(this, "Camera overlay activated", Toast.LENGTH_SHORT).show();
        });

        btnSettings.setOnClickListener(v ->
            startActivity(new Intent(this, PermissionActivity.class)));
    }

    // ─── Broadcast Receivers ─────────────────────────────────────────────

    private void setupBroadcastReceivers() {
        // JARVIS state changes (ACTIVE, STANDBY, WAKE, etc.)
        stateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String state = intent.getStringExtra("state");
                handleStateChange(state);
            }
        };

        // Transcript updates from Gemini
        transcriptReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String role = intent.getStringExtra("role");
                String text = intent.getStringExtra("text");
                updateTranscript(role, text);
            }
        };

        // Audio level for waveform
        audioLevelReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                float level = intent.getFloatExtra("level", 0f);
                setHologramAudioLevel(level);
            }
        };

        registerReceiver(stateReceiver,
            new IntentFilter(JarvisService.BROADCAST_STATE));
        registerReceiver(transcriptReceiver,
            new IntentFilter(JarvisService.BROADCAST_TRANSCRIPT));
        registerReceiver(audioLevelReceiver,
            new IntentFilter("com.furqan.jarvis.AUDIO_LEVEL"));
    }

    private void handleStateChange(String state) {
        if (state == null) return;
        switch (state) {
            case "WAKE":
            case "ACTIVE":
                statusText.setText("LISTENING");
                statusText.setTextColor(0xFF00FF88);
                setHologramState("LISTENING");
                break;
            case "STANDBY":
                statusText.setText("STANDBY  ·  Say \"Hey Jarvis\"");
                statusText.setTextColor(0xFF0088CC);
                setHologramState("STANDBY");
                break;
            case "SPEAKING":
                statusText.setText("JARVIS SPEAKING");
                statusText.setTextColor(0xFF00CCFF);
                setHologramState("SPEAKING");
                break;
            case "PROCESSING":
                statusText.setText("PROCESSING");
                statusText.setTextColor(0xFFFFAA00);
                setHologramState("PROCESSING");
                break;
            case "CONNECTED":
                statusText.setText("ONLINE  ·  LISTENING");
                statusText.setTextColor(0xFF00FF88);
                break;
        }
    }

    private void updateTranscript(String role, String text) {
        // Strip action commands from display text
        String displayText = text.replaceAll("\\[ACTION:[^]]*]", "").trim();
        if (displayText.isEmpty()) return;

        String prefix = "user".equals(role) ? "You: " : "JARVIS: ";
        transcriptText.setText(prefix + displayText);

        // Auto-hide after 5 seconds
        transcriptText.removeCallbacks(hideTranscriptRunnable);
        transcriptText.postDelayed(hideTranscriptRunnable, 5000);
    }

    private final Runnable hideTranscriptRunnable = () ->
        transcriptText.setText("");

    // ─── Service Connection ───────────────────────────────────────────────

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            JarvisService.JarvisBinder jb = (JarvisService.JarvisBinder) binder;
            jarvisService = jb.getService();
            serviceBound = true;
            Log.d(TAG, "Bound to JarvisService");

            // Update UI with current state
            if (jarvisService.getServiceState() == JarvisService.State.ACTIVE) {
                handleStateChange("ACTIVE");
            } else {
                handleStateChange("STANDBY");
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            jarvisService = null;
            serviceBound = false;
        }
    };

    private void startJarvisService() {
        Intent intent = new Intent(this, JarvisService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    // ─── Permissions ─────────────────────────────────────────────────────

    private void checkAndRequestPermissions() {
        List<String> missing = new ArrayList<>();
        for (String perm : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, perm) !=
                PackageManager.PERMISSION_GRANTED) {
                missing.add(perm);
            }
        }
        if (!missing.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                missing.toArray(new String[0]), PERM_REQUEST);
        }

        // Check overlay permission separately
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !Settings.canDrawOverlays(this)) {
            Intent overlayIntent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:" + getPackageName()));
            startActivityForResult(overlayIntent, 200);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                            int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERM_REQUEST) {
            Log.d(TAG, "Permissions granted");
            startJarvisService();
        }
    }

    // ─── Lifecycle ────────────────────────────────────────────────────────

    @Override
    protected void onResume() {
        super.onResume();
        // Re-hide system UI
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (serviceBound) {
            unbindService(serviceConnection);
            serviceBound = false;
        }
        try {
            unregisterReceiver(stateReceiver);
            unregisterReceiver(transcriptReceiver);
            unregisterReceiver(audioLevelReceiver);
        } catch (Exception ignored) {}
    }
}
