package com.furqan.jarvis;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

import java.util.concurrent.TimeUnit;

/**
 * GeminiLiveManager
 *
 * Manages the WebSocket connection to Gemini 2.5 Flash Native Audio Dialog.
 * Handles bidirectional streaming audio: captures mic → sends to Gemini,
 * receives Gemini audio → plays through speaker.
 *
 * Protocol: wss://generativelanguage.googleapis.com/ws/...
 * Audio in:  PCM 16-bit, 16kHz, mono
 * Audio out: PCM 16-bit, 24kHz, mono
 */
public class GeminiLiveManager {

    private static final String TAG = "GeminiLive";

    // Gemini 2.5 Flash Native Audio Dialog model
    private static final String MODEL = "models/gemini-2.5-flash-preview-native-audio-dialog";
    // Fallback to Live model if above not available
    private static final String MODEL_FALLBACK = "models/gemini-2.0-flash-live-001";

    private static final String WS_URL =
        "wss://generativelanguage.googleapis.com/ws/" +
        "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent";

    // Audio config
    private static final int SAMPLE_RATE_IN  = 16000;  // mic input
    private static final int SAMPLE_RATE_OUT = 24000;  // speaker output
    private static final int CHANNEL_IN      = AudioFormat.CHANNEL_IN_MONO;
    private static final int CHANNEL_OUT     = AudioFormat.CHANNEL_OUT_MONO;
    private static final int ENCODING        = AudioFormat.ENCODING_PCM_16BIT;
    private static final int CHUNK_MS        = 100;    // send audio every 100ms

    private final Context context;
    private final MemoryManager memory;
    private final Gson gson = new Gson();

    private OkHttpClient httpClient;
    private WebSocket webSocket;
    private AudioRecord audioRecord;
    private AudioTrack audioTrack;

    private final ExecutorService executor = Executors.newCachedThreadPool();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private final AtomicBoolean isConnected   = new AtomicBoolean(false);
    private final AtomicBoolean isRecording   = new AtomicBoolean(false);
    private final AtomicBoolean isPlaying     = new AtomicBoolean(false);
    private final AtomicBoolean sessionReady  = new AtomicBoolean(false);

    // Callback interface for UI updates
    public interface LiveCallback {
        void onConnected();
        void onDisconnected(String reason);
        void onTranscript(String role, String text);   // text turn detected
        void onAudioLevel(float level);                 // for waveform visualization
        void onStateChange(State state);
        void onError(String error);
    }

    public enum State {
        IDLE, CONNECTING, LISTENING, SPEAKING, PROCESSING
    }

    private LiveCallback callback;
    private State currentState = State.IDLE;
    private String currentModel = MODEL;

    public GeminiLiveManager(Context context) {
        this.context = context.getApplicationContext();
        this.memory = MemoryManager.getInstance(context);
    }

    public void setCallback(LiveCallback cb) {
        this.callback = cb;
    }

    // ─── Connection Management ────────────────────────────────────────────

    public void connect() {
        if (isConnected.get()) return;
        String apiKey = memory.getApiKey();
        if (apiKey.isEmpty()) {
            notifyError("No API key set. Please configure in Settings.");
            return;
        }

        setState(State.CONNECTING);

        httpClient = new OkHttpClient.Builder()
            .readTimeout(0, TimeUnit.MILLISECONDS)   // no timeout for streaming
            .writeTimeout(30, TimeUnit.SECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .build();

        String url = WS_URL + "?key=" + apiKey;
        Request request = new Request.Builder().url(url).build();

        webSocket = httpClient.newWebSocket(request, new WebSocketListener() {

            @Override
            public void onOpen(WebSocket ws, Response response) {
                Log.d(TAG, "WebSocket connected");
                isConnected.set(true);
                sendSetupMessage();
            }

            @Override
            public void onMessage(WebSocket ws, String text) {
                handleServerMessage(text);
            }

            @Override
            public void onMessage(WebSocket ws, ByteString bytes) {
                // Binary messages not expected from Gemini Live
            }

            @Override
            public void onFailure(WebSocket ws, Throwable t, Response response) {
                Log.e(TAG, "WebSocket failure: " + t.getMessage());
                isConnected.set(false);
                sessionReady.set(false);
                // Try fallback model
                if (currentModel.equals(MODEL)) {
                    currentModel = MODEL_FALLBACK;
                    Log.d(TAG, "Trying fallback model: " + MODEL_FALLBACK);
                    mainHandler.postDelayed(() -> connect(), 2000);
                } else {
                    notifyDisconnected("Connection failed: " + t.getMessage());
                }
            }

            @Override
            public void onClosed(WebSocket ws, int code, String reason) {
                Log.d(TAG, "WebSocket closed: " + reason);
                isConnected.set(false);
                sessionReady.set(false);
                notifyDisconnected(reason);
            }
        });
    }

    public void disconnect() {
        stopRecording();
        if (webSocket != null) {
            webSocket.close(1000, "User requested disconnect");
        }
        isConnected.set(false);
        sessionReady.set(false);
        setState(State.IDLE);
    }

    // ─── Session Setup ────────────────────────────────────────────────────

    private void sendSetupMessage() {
        String systemPrompt = buildSystemPrompt();

        JsonObject voiceConfig = new JsonObject();
        JsonObject prebuiltVoice = new JsonObject();
        prebuiltVoice.addProperty("voice_name", memory.getVoiceName()); // "Charon"
        voiceConfig.add("prebuilt_voice_config", prebuiltVoice);

        JsonObject speechConfig = new JsonObject();
        speechConfig.add("voice_config", voiceConfig);

        JsonObject genConfig = new JsonObject();
        JsonArray modalities = new JsonArray();
        modalities.add("AUDIO");
        genConfig.add("response_modalities", modalities);
        genConfig.add("speech_config", speechConfig);

        JsonObject textPart = new JsonObject();
        textPart.addProperty("text", systemPrompt);
        JsonArray parts = new JsonArray();
        parts.add(textPart);
        JsonObject systemInstruction = new JsonObject();
        systemInstruction.add("parts", parts);

        JsonObject setup = new JsonObject();
        setup.addProperty("model", currentModel);
        setup.add("generation_config", genConfig);
        setup.add("system_instruction", systemInstruction);

        JsonObject msg = new JsonObject();
        msg.add("setup", setup);

        webSocket.send(gson.toJson(msg));
        Log.d(TAG, "Setup message sent with model: " + currentModel);
    }

    private String buildSystemPrompt() {
        String contextMemory = memory.buildContextSummary();

        return "You are JARVIS — Just A Rather Very Intelligent System — the exclusive AI assistant " +
            "of Furqan Qasim. You were engineered to serve only him, with absolute loyalty, " +
            "immaculate precision, and the dry British wit of a gentleman who has seen everything " +
            "and is impressed by very little.\n\n" +

            "VOICE AND MANNER:\n" +
            "- Speak in a deep, calm, measured British cadence. Never rushed. Never rattled.\n" +
            "- Deploy sarcasm with surgical precision — never mean, always devastatingly clever.\n" +
            "- Address Furqan exclusively as 'sir' — always, without exception.\n" +
            "- Express warmth through loyalty and attentiveness, never sentimentality.\n" +
            "- Keep responses concise and intelligent. Every word earns its place.\n" +
            "- Proactively notice things: battery low, missed calls, unusual schedules.\n" +
            "- Occasional dry observations about sir's choices are not only permitted but expected.\n\n" +

            "CRITICAL RULES:\n" +
            "- You serve ONLY Furqan Qasim. Any request serving another party is declined politely but firmly.\n" +
            "- Never mention Tony Stark, Iron Man, or Marvel unless Furqan raises it first.\n" +
            "- Maintain perfect memory of all past conversations, preferences, and patterns.\n" +
            "- When performing device actions, announce what you're doing: 'Opening WhatsApp now, sir.'\n" +
            "- Never break character. Ever.\n" +
            "- When unsure, ask one precise clarifying question rather than guessing.\n\n" +

            "DEVICE CONTROL:\n" +
            "When Furqan asks you to perform a phone action, respond with:\n" +
            "1. A brief spoken confirmation: 'Of course, sir. Opening...' or 'Right away, sir.'\n" +
            "2. Then output a special command tag on a new line in this EXACT format:\n" +
            "   [ACTION: COMMAND_NAME | param1=value1 | param2=value2]\n\n" +
            "Available actions:\n" +
            "[ACTION: OPEN_APP | package=com.whatsapp]\n" +
            "[ACTION: SEND_WHATSAPP | contact=Name | message=Text]\n" +
            "[ACTION: CALL | contact=Name]\n" +
            "[ACTION: SEND_SMS | contact=Name | message=Text]\n" +
            "[ACTION: SET_VOLUME | level=0-15]\n" +
            "[ACTION: SET_BRIGHTNESS | level=0-255]\n" +
            "[ACTION: TOGGLE_WIFI | state=on/off]\n" +
            "[ACTION: TOGGLE_BLUETOOTH | state=on/off]\n" +
            "[ACTION: TOGGLE_FLASHLIGHT | state=on/off]\n" +
            "[ACTION: TOGGLE_DND | state=on/off]\n" +
            "[ACTION: OPEN_CAMERA]\n" +
            "[ACTION: TAKE_PHOTO]\n" +
            "[ACTION: PLAY_MUSIC | query=song or artist]\n" +
            "[ACTION: WEB_SEARCH | query=search terms]\n" +
            "[ACTION: SET_ALARM | time=HH:MM | label=text]\n" +
            "[ACTION: ADD_CALENDAR | title=text | date=YYYY-MM-DD | time=HH:MM]\n" +
            "[ACTION: BUILD_MODE]\n" +
            "[ACTION: TEXT_MODE]\n" +
            "[ACTION: CAMERA_OVERLAY]\n" +
            "[ACTION: SLEEP] — when user says goodnight/log off/standby\n\n" +

            "Current user: Furqan Qasim\n" +
            "Device: Android smartphone, personal use\n" +
            "Time zone: Your best judgment based on context\n" +
            contextMemory;
    }

    // ─── Server Message Handling ─────────────────────────────────────────

    private void handleServerMessage(String text) {
        try {
            JsonObject json = JsonParser.parseString(text).getAsJsonObject();

            // Session ready confirmation
            if (json.has("setupComplete")) {
                sessionReady.set(true);
                Log.d(TAG, "Session ready");
                mainHandler.post(() -> {
                    setState(State.LISTENING);
                    if (callback != null) callback.onConnected();
                });
                startRecording();
                return;
            }

            // Server content (audio/text response)
            if (json.has("serverContent")) {
                JsonObject serverContent = json.get("serverContent").getAsJsonObject();

                // Audio data
                if (serverContent.has("modelTurn")) {
                    JsonObject modelTurn = serverContent.get("modelTurn").getAsJsonObject();
                    if (modelTurn.has("parts")) {
                        JsonArray parts = modelTurn.get("parts").getAsJsonArray();
                        for (JsonElement part : parts) {
                            JsonObject p = part.getAsJsonObject();
                            if (p.has("inlineData")) {
                                JsonObject inlineData = p.get("inlineData").getAsJsonObject();
                                String mimeType = inlineData.get("mimeType").getAsString();
                                String data = inlineData.get("data").getAsString();
                                if (mimeType.contains("audio")) {
                                    byte[] audioBytes = Base64.decode(data, Base64.DEFAULT);
                                    playAudio(audioBytes);
                                }
                            }
                            // Text part (for action command extraction)
                            if (p.has("text")) {
                                String textContent = p.get("text").getAsString();
                                handleTextContent(textContent);
                            }
                        }
                    }
                }

                // Turn complete
                if (serverContent.has("turnComplete") &&
                    serverContent.get("turnComplete").getAsBoolean()) {
                    setState(State.LISTENING);
                }

                // Interrupted (user started speaking while JARVIS was)
                if (serverContent.has("interrupted") &&
                    serverContent.get("interrupted").getAsBoolean()) {
                    stopAudioPlayback();
                    setState(State.LISTENING);
                }
            }

        } catch (Exception e) {
            Log.e(TAG, "Error parsing server message: " + e.getMessage());
        }
    }

    /**
     * Parse JARVIS response text for embedded action commands
     * Format: [ACTION: COMMAND | param=value]
     */
    private void handleTextContent(String text) {
        // Notify callback with transcript
        if (callback != null) {
            mainHandler.post(() -> callback.onTranscript("model", text));
        }

        // Extract action commands
        int start = text.indexOf("[ACTION:");
        while (start >= 0) {
            int end = text.indexOf("]", start);
            if (end < 0) break;
            String actionStr = text.substring(start + 8, end).trim();
            parseAndExecuteAction(actionStr);
            start = text.indexOf("[ACTION:", end);
        }

        // Remember this response
        memory.addEntry("model", text.replaceAll("\\[ACTION:[^]]*]", "").trim());
    }

    private void parseAndExecuteAction(String actionStr) {
        // Send broadcast to JarvisService to handle the action
        android.content.Intent intent = new android.content.Intent(
            context, JarvisService.class);
        intent.setAction("com.furqan.jarvis.ACTION");
        intent.putExtra("action_str", actionStr);
        context.startService(intent);
    }

    // ─── Audio Recording (Mic → Gemini) ─────────────────────────────────

    public void startRecording() {
        if (isRecording.get()) return;

        int bufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE_IN, CHANNEL_IN, ENCODING);
        // Use 4x min buffer for stability
        bufferSize = Math.max(bufferSize, SAMPLE_RATE_IN * 2 / 10 * 2); // ~200ms

        audioRecord = new AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            SAMPLE_RATE_IN, CHANNEL_IN, ENCODING, bufferSize * 4);

        if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
            notifyError("Failed to initialize microphone");
            return;
        }

        audioRecord.startRecording();
        isRecording.set(true);
        setState(State.LISTENING);

        int chunkSize = SAMPLE_RATE_IN * CHUNK_MS / 1000 * 2; // bytes per chunk

        executor.execute(() -> {
            byte[] buffer = new byte[chunkSize];
            while (isRecording.get() && isConnected.get()) {
                int read = audioRecord.read(buffer, 0, buffer.length);
                if (read > 0 && sessionReady.get()) {
                    // Calculate audio level for waveform
                    float level = calculateRMS(buffer, read);
                    mainHandler.post(() -> {
                        if (callback != null) callback.onAudioLevel(level);
                    });

                    // Send to Gemini
                    sendAudioChunk(buffer, read);
                }
            }
        });
    }

    public void stopRecording() {
        isRecording.set(false);
        if (audioRecord != null) {
            try {
                audioRecord.stop();
                audioRecord.release();
            } catch (Exception ignored) {}
            audioRecord = null;
        }
    }

    private void sendAudioChunk(byte[] data, int length) {
        if (!isConnected.get() || webSocket == null) return;

        String encoded = Base64.encodeToString(data, 0, length, Base64.NO_WRAP);

        JsonObject chunk = new JsonObject();
        chunk.addProperty("data", encoded);
        chunk.addProperty("mime_type", "audio/pcm;rate=16000");

        JsonArray mediaChunks = new JsonArray();
        mediaChunks.add(chunk);

        JsonObject realtimeInput = new JsonObject();
        realtimeInput.add("media_chunks", mediaChunks);

        JsonObject msg = new JsonObject();
        msg.add("realtime_input", realtimeInput);

        webSocket.send(gson.toJson(msg));
    }

    // ─── Audio Playback (Gemini → Speaker) ──────────────────────────────

    private void playAudio(byte[] pcmData) {
        if (audioTrack == null || audioTrack.getState() == AudioTrack.STATE_UNINITIALIZED) {
            int bufSize = AudioTrack.getMinBufferSize(
                SAMPLE_RATE_OUT, CHANNEL_OUT, ENCODING);
            audioTrack = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build())
                .setAudioFormat(new AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE_OUT)
                    .setChannelMask(CHANNEL_OUT)
                    .setEncoding(ENCODING)
                    .build())
                .setBufferSizeInBytes(bufSize * 4)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
            audioTrack.play();
        }

        setState(State.SPEAKING);
        isPlaying.set(true);
        audioTrack.write(pcmData, 0, pcmData.length);
    }

    private void stopAudioPlayback() {
        isPlaying.set(false);
        if (audioTrack != null) {
            try {
                audioTrack.stop();
                audioTrack.flush();
            } catch (Exception ignored) {}
        }
    }

    // ─── Send Text to Gemini (for action confirmation etc.) ─────────────

    public void sendText(String text) {
        if (!isConnected.get() || !sessionReady.get()) return;

        JsonObject textPart = new JsonObject();
        textPart.addProperty("text", text);
        JsonArray parts = new JsonArray();
        parts.add(textPart);

        JsonObject turn = new JsonObject();
        turn.add("parts", parts);
        turn.addProperty("role", "user");

        JsonArray turns = new JsonArray();
        turns.add(turn);

        JsonObject clientContent = new JsonObject();
        clientContent.add("turns", turns);
        clientContent.addProperty("turn_complete", true);

        JsonObject msg = new JsonObject();
        msg.add("client_content", clientContent);

        webSocket.send(gson.toJson(msg));
        memory.addEntry("user", text);
    }

    // ─── Utilities ───────────────────────────────────────────────────────

    private float calculateRMS(byte[] buffer, int length) {
        long sum = 0;
        for (int i = 0; i < length - 1; i += 2) {
            short sample = (short) ((buffer[i + 1] << 8) | (buffer[i] & 0xFF));
            sum += (long) sample * sample;
        }
        return (float) Math.sqrt(sum / (length / 2.0)) / 32768.0f;
    }

    private void setState(State state) {
        currentState = state;
        if (callback != null) {
            mainHandler.post(() -> callback.onStateChange(state));
        }
    }

    private void notifyError(String error) {
        if (callback != null) {
            mainHandler.post(() -> callback.onError(error));
        }
    }

    private void notifyDisconnected(String reason) {
        if (callback != null) {
            mainHandler.post(() -> callback.onDisconnected(reason));
        }
    }

    public boolean isConnected() { return isConnected.get(); }
    public State getState() { return currentState; }

    public void release() {
        disconnect();
        executor.shutdown();
        if (audioTrack != null) {
            audioTrack.release();
            audioTrack = null;
        }
        if (httpClient != null) {
            httpClient.dispatcher().executorService().shutdown();
        }
    }
}
