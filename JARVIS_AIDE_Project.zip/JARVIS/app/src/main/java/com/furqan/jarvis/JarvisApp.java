package com.furqan.jarvis;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

/**
 * JARVIS Application Class
 * Global initialization — runs before any Activity or Service
 */
public class JarvisApp extends Application {

    public static final String CHANNEL_ID_MAIN    = "jarvis_main";
    public static final String CHANNEL_ID_ALERT   = "jarvis_alert";
    public static final String CHANNEL_ID_SILENT  = "jarvis_silent";

    // Global reference to accessibility service (set when service connects)
    public static JarvisAccessibilityService accessibilityService;

    // Global reference to the live manager
    public static GeminiLiveManager liveManager;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannels();
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);

            // Main persistent channel — shown while JARVIS is running
            NotificationChannel main = new NotificationChannel(
                CHANNEL_ID_MAIN,
                "JARVIS Active",
                NotificationManager.IMPORTANCE_LOW
            );
            main.setDescription("JARVIS background service");
            main.setShowBadge(false);
            nm.createNotificationChannel(main);

            // Alert channel — for proactive JARVIS notifications
            NotificationChannel alert = new NotificationChannel(
                CHANNEL_ID_ALERT,
                "JARVIS Alerts",
                NotificationManager.IMPORTANCE_HIGH
            );
            alert.setDescription("JARVIS proactive notifications");
            nm.createNotificationChannel(alert);

            // Silent channel — for status updates
            NotificationChannel silent = new NotificationChannel(
                CHANNEL_ID_SILENT,
                "JARVIS Status",
                NotificationManager.IMPORTANCE_MIN
            );
            silent.setDescription("JARVIS status information");
            nm.createNotificationChannel(silent);
        }
    }
}
