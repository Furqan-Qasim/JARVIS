package com.furqan.jarvis;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;

import androidx.core.app.NotificationCompat;

/**
 * JarvisService — The Heart of JARVIS
 *
 * A persistent ForegroundService that runs 24/7 even when the app is swiped away.
 * Manages the full JARVIS lifecycle:
 *   - STANDBY: Hotword detection only (minimal power)
 *   - ACTIVE:  Full Gemini Live conversation
 *   - SLEEPING: Service alive but detection paused
 *
 * Uses stopWithTask=false in manifest to survive swipe-to-kill.
 * BootReceiver restarts it after reboot.
 * Holds a partial wake lock to keep CPU alive for hotword detection.
 */
public class JarvisService extends Service {

    private static final String TAG = "JarvisService";
    private static final int NOTIF_ID = 1001;

    public static final String ACTION_WAKE   = "com.furqan.jarvis.WAKE";
    public static final String ACTION_SLEEP  = "com.furqan.jarvis.SLEEP";
    public static final String ACTION_STOP   = "com.furqan.jarvis.STOP";
    public static final String ACTION_ACTION = "com.furqan.jarvis.ACTION";

    // Service states
    public enum State { STANDBY, ACTIVE, SLEEPING }
    private State serviceState = State.STANDBY;

    private GeminiLiveManager geminiLive;
    private HotwordDetector hotwordDetector;
    private DeviceController deviceController;
    private MemoryManager memory;
    private PowerManager.WakeLock wakeLock;

    // Binder for Activity communication
    private final IBinder binder = new JarvisBinder();
    public class JarvisBinder extends Binder {
        JarvisService getService() { return JarvisService.this; }
    }

    // Broadcast to update UI
    public static final String BROADCAST_STATE = "com.furqan.jarvis.STATE";
    public static final String BROADCAST_TRANSCRIPT = "com.furqan.jarvis.TRANSCRIPT";

    // Static reference so activities can check state
    public static JarvisService instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        Log.d(TAG, "Service created");

        memory = MemoryManager.getInstance(this);
        deviceController = new DeviceController(this);

        // Acquire partial wake lock to keep CPU running for hotword detection
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "JARVIS::BackgroundLock");
        wakeLock.acquire(); // Hold indefinitely (released on service destroy)

        // Store global reference
        JarvisApp.liveManager = geminiLive = new GeminiLiveManager(this);

        setupGeminiCallbacks();
        setupHotwordDetector();
        startForegroundNotification();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
                case ACTION_WAKE:
                    activateJarvis();
                    break;
                case ACTION_SLEEP:
                    deactivateJarvis();
                    break;
                case ACTION_STOP:
                    stopSelf();
                    break;
                case ACTION_ACTION:
                    String actionStr = intent.getStringExtra("action_str");
                    if (actionStr != null) {
                        handleDeviceAction(actionStr);
                    }
                    break;
            }
        }
        // START_STICKY: Android will restart this service if killed
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return true; // Allow re-binding
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // App was swiped away — restart the service
        super.onTaskRemoved(rootIntent);
        Log.d(TAG, "Task removed — scheduling restart");
        Intent restartIntent = new Intent(getApplicationContext(), JarvisService.class);
        restartIntent.setPackage(getPackageName());
        PendingIntent pending = PendingIntent.getService(this, 1, restartIntent,
            PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);
        android.app.AlarmManager am = (android.app.AlarmManager) getSystemService(ALARM_SERVICE);
        am.set(android.app.AlarmManager.ELAPSED_REALTIME,
            android.os.SystemClock.elapsedRealtime() + 1000, pending);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Service destroyed — will restart");
        if (geminiLive != null) geminiLive.release();
        if (hotwordDetector != null) hotwordDetector.stop();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        instance = null;

        // Schedule immediate restart
        Intent restartIntent = new Intent(getApplicationContext(), JarvisService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(restartIntent);
        } else {
            startService(restartIntent);
        }
    }

    // ─── Lifecycle: Activate / Deactivate ────────────────────────────────

    public void activateJarvis() {
        Log.d(TAG, "Activating JARVIS");
        serviceState = State.ACTIVE;

        // Switch hotword detector to sleep-word monitoring
        hotwordDetector.setHotwordMode(false);

        // Connect to Gemini Live if not connected
        if (!geminiLive.isConnected()) {
            geminiLive.connect();
        } else {
            geminiLive.startRecording();
        }

        updateNotification("Active — Listening");
        broadcastState("ACTIVE");
        deviceController.vibrate(50);
    }

    public void deactivateJarvis() {
        Log.d(TAG, "JARVIS entering standby");
        serviceState = State.STANDBY;

        // Send sleep confirmation via text (Gemini will speak it if connected)
        if (geminiLive.isConnected()) {
            geminiLive.sendText("[SYSTEM: User said sleep command. Say a brief, witty British goodbye. Keep it under 10 words.]");
        }

        // After a short delay, stop recording and return to hotword mode
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            geminiLive.stopRecording();
            hotwordDetector.setHotwordMode(true);
            updateNotification("Standby — Say \"Hey Jarvis\"");
            broadcastState("STANDBY");
        }, 3000);
    }

    // ─── Hotword Detector Setup ───────────────────────────────────────────

    private void setupHotwordDetector() {
        hotwordDetector = new HotwordDetector(this);
        hotwordDetector.setCallback(new HotwordDetector.HotwordCallback() {
            @Override
            public void onHotwordDetected() {
                Log.d(TAG, "Hotword detected!");
                if (serviceState != State.ACTIVE) {
                    activateJarvis();
                    // Tell UI to wake the hologram
                    broadcastState("WAKE");
                }
            }

            @Override
            public void onSleepDetected() {
                Log.d(TAG, "Sleep command detected");
                if (serviceState == State.ACTIVE) {
                    deactivateJarvis();
                }
            }

            @Override
            public void onPartialResult(String partial) {
                // Could use this for partial UI feedback
            }
        });
        hotwordDetector.start();
    }

    // ─── Gemini Live Callbacks ────────────────────────────────────────────

    private void setupGeminiCallbacks() {
        geminiLive.setCallback(new GeminiLiveManager.LiveCallback() {

            @Override
            public void onConnected() {
                Log.d(TAG, "Gemini Live connected");
                broadcastState("CONNECTED");
                updateNotification("Active — Listening");
            }

            @Override
            public void onDisconnected(String reason) {
                Log.d(TAG, "Gemini disconnected: " + reason);
                if (serviceState == State.ACTIVE) {
                    // Auto-reconnect after short delay
                    new android.os.Handler(android.os.Looper.getMainLooper())
                        .postDelayed(() -> {
                            if (serviceState == State.ACTIVE) {
                                geminiLive.connect();
                            }
                        }, 3000);
                }
            }

            @Override
            public void onTranscript(String role, String text) {
                // Broadcast transcript for UI
                Intent i = new Intent(BROADCAST_TRANSCRIPT);
                i.putExtra("role", role);
                i.putExtra("text", text);
                sendBroadcast(i);

                // Check for sleep command in model response (JARVIS said goodbye)
                if (role.equals("model") && (
                    text.toLowerCase().contains("logging off") ||
                    text.toLowerCase().contains("going to sleep") ||
                    text.toLowerCase().contains("powering down"))) {
                    // Will deactivate after playback
                }
            }

            @Override
            public void onAudioLevel(float level) {
                Intent i = new Intent("com.furqan.jarvis.AUDIO_LEVEL");
                i.putExtra("level", level);
                sendBroadcast(i);
            }

            @Override
            public void onStateChange(GeminiLiveManager.State state) {
                String stateStr = state.name();
                Intent i = new Intent("com.furqan.jarvis.GEMINI_STATE");
                i.putExtra("state", stateStr);
                sendBroadcast(i);
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "Gemini error: " + error);
                Intent i = new Intent("com.furqan.jarvis.ERROR");
                i.putExtra("error", error);
                sendBroadcast(i);
            }
        });
    }

    // ─── Device Action Handling ───────────────────────────────────────────

    private void handleDeviceAction(String actionStr) {
        Log.d(TAG, "Executing device action: " + actionStr);
        String result = deviceController.executeAction(actionStr);
        Log.d(TAG, "Action result: " + result);

        // Special actions that affect service state
        if (actionStr.contains("SLEEP")) {
            deactivateJarvis();
        }
    }

    // ─── Foreground Notification ──────────────────────────────────────────

    private void startForegroundNotification() {
        Notification notification = buildNotification("Initializing...");
        startForeground(NOTIF_ID, notification);
    }

    private void updateNotification(String status) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIF_ID, buildNotification(status));
    }

    private Notification buildNotification(String status) {
        Intent mainIntent = new Intent(this, MainActivity.class);
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingMain = PendingIntent.getActivity(this, 0, mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent sleepIntent = new Intent(this, JarvisService.class);
        sleepIntent.setAction(ACTION_SLEEP);
        PendingIntent pendingSleep = PendingIntent.getService(this, 1, sleepIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, JarvisApp.CHANNEL_ID_MAIN)
            .setContentTitle("JARVIS")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingMain)
            .setOngoing(true)
            .setSilent(true)
            .addAction(android.R.drawable.ic_media_pause, "Standby", pendingSleep)
            .build();
    }

    // ─── Broadcast Utilities ─────────────────────────────────────────────

    private void broadcastState(String state) {
        Intent i = new Intent(BROADCAST_STATE);
        i.putExtra("state", state);
        sendBroadcast(i);
    }

    // ─── Public API for Activities ────────────────────────────────────────

    public State getServiceState() { return serviceState; }
    public GeminiLiveManager getLiveManager() { return geminiLive; }
    public DeviceController getDeviceController() { return deviceController; }

    public void sendTextToJarvis(String text) {
        if (serviceState == State.ACTIVE && geminiLive.isConnected()) {
            geminiLive.sendText(text);
            memory.addEntry("user", text);
        }
    }
}
