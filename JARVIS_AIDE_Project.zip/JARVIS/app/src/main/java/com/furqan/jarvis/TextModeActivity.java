package com.furqan.jarvis;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * TextModeActivity
 *
 * Full-screen chat UI for text-based interaction with JARVIS.
 * Uses Gemini 1.5 Flash (free tier) for text completions.
 * Accessible via button or "Hey Jarvis, switch to text mode".
 */
public class TextModeActivity extends AppCompatActivity {

    private static final String TAG = "TextMode";
    // Free tier Gemini model for text
    private static final String TEXT_MODEL = "gemini-1.5-flash";
    private static final String API_BASE = "https://generativelanguage.googleapis.com/v1beta/models/";

    private RecyclerView chatRecycler;
    private EditText inputField;
    private ImageButton sendBtn;
    private ImageButton backBtn;
    private TextView typingIndicator;

    private final List<ChatMessage> messages = new ArrayList<>();
    private ChatAdapter adapter;
    private final OkHttpClient httpClient = new OkHttpClient();
    private final Gson gson = new Gson();
    private MemoryManager memory;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        setContentView(R.layout.activity_text_mode);

        memory = MemoryManager.getInstance(this);

        chatRecycler    = findViewById(R.id.chat_recycler);
        inputField      = findViewById(R.id.input_field);
        sendBtn         = findViewById(R.id.send_btn);
        backBtn         = findViewById(R.id.back_btn);
        typingIndicator = findViewById(R.id.typing_indicator);

        adapter = new ChatAdapter(messages);
        chatRecycler.setAdapter(adapter);
        chatRecycler.setLayoutManager(new LinearLayoutManager(this) {{
            setStackFromEnd(true);
        }});

        sendBtn.setOnClickListener(v -> sendMessage());
        backBtn.setOnClickListener(v -> finish());

        inputField.setOnEditorActionListener((v, actionId, event) -> {
            if (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                sendMessage();
                return true;
            }
            return false;
        });

        // Show greeting
        addMessage("model",
            "Text interface online, sir. How may I be of service?");
    }

    private void sendMessage() {
        String text = inputField.getText().toString().trim();
        if (TextUtils.isEmpty(text)) return;

        inputField.setText("");
        addMessage("user", text);
        memory.addEntry("user", text);
        showTyping(true);

        callGeminiText(text);
    }

    private void callGeminiText(String userText) {
        String apiKey = memory.getApiKey();
        if (apiKey.isEmpty()) {
            addMessage("model", "No API key configured, sir. Please visit Settings.");
            showTyping(false);
            return;
        }

        // Build conversation history
        JsonArray contents = new JsonArray();

        // Add recent memory
        List<MemoryManager.MemoryEntry> history = memory.getRecentHistory(20);
        for (MemoryManager.MemoryEntry entry : history) {
            if (!entry.role.equals("system")) {
                JsonArray parts = new JsonArray();
                JsonObject part = new JsonObject();
                part.addProperty("text", entry.text);
                parts.add(part);
                JsonObject msg = new JsonObject();
                msg.addProperty("role", entry.role.equals("model") ? "model" : "user");
                msg.add("parts", parts);
                contents.add(msg);
            }
        }

        // Add current user message
        JsonArray parts = new JsonArray();
        JsonObject part = new JsonObject();
        part.addProperty("text", userText);
        parts.add(part);
        JsonObject userMsg = new JsonObject();
        userMsg.addProperty("role", "user");
        userMsg.add("parts", parts);
        contents.add(userMsg);

        // System instruction
        JsonObject systemPart = new JsonObject();
        systemPart.addProperty("text", buildTextSystemPrompt());
        JsonArray sysParts = new JsonArray();
        sysParts.add(systemPart);
        JsonObject sysInstruction = new JsonObject();
        sysInstruction.add("parts", sysParts);

        JsonObject requestBody = new JsonObject();
        requestBody.add("contents", contents);
        requestBody.add("system_instruction", sysInstruction);

        // Config
        JsonObject genConfig = new JsonObject();
        genConfig.addProperty("temperature", 0.8);
        genConfig.addProperty("max_output_tokens", 2048);
        requestBody.add("generationConfig", genConfig);

        String url = API_BASE + TEXT_MODEL + ":generateContent?key=" + apiKey;
        Request request = new Request.Builder()
            .url(url)
            .post(RequestBody.create(
                gson.toJson(requestBody),
                MediaType.parse("application/json")))
            .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    showTyping(false);
                    addMessage("model", "My apologies, sir — connection issue: " + e.getMessage());
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseBody = response.body().string();
                runOnUiThread(() -> {
                    showTyping(false);
                    try {
                        JsonObject json = gson.fromJson(responseBody, JsonObject.class);
                        if (json.has("candidates")) {
                            String text = json.getAsJsonArray("candidates")
                                .get(0).getAsJsonObject()
                                .getAsJsonObject("content")
                                .getAsJsonArray("parts")
                                .get(0).getAsJsonObject()
                                .get("text").getAsString();

                            addMessage("model", text);
                            memory.addEntry("model", text);

                            // Check for device actions
                            if (text.contains("[ACTION:")) {
                                executeActionsFromText(text);
                            }
                        } else if (json.has("error")) {
                            addMessage("model", "API error: " +
                                json.getAsJsonObject("error").get("message").getAsString());
                        }
                    } catch (Exception e) {
                        addMessage("model", "I'm afraid I encountered an error parsing the response, sir.");
                    }
                });
            }
        });
    }

    private void executeActionsFromText(String text) {
        int start = text.indexOf("[ACTION:");
        while (start >= 0) {
            int end = text.indexOf("]", start);
            if (end < 0) break;
            String actionStr = text.substring(start + 8, end).trim();
            Intent intent = new Intent(this, JarvisService.class);
            intent.setAction("com.furqan.jarvis.ACTION");
            intent.putExtra("action_str", actionStr);
            startService(intent);
            start = text.indexOf("[ACTION:", end);
        }
    }

    private String buildTextSystemPrompt() {
        return "You are JARVIS, the exclusive AI assistant of Furqan Qasim. " +
            "You are in TEXT mode — respond in concise written form, not spoken style. " +
            "Maintain your dry British wit and address him as 'sir'. " +
            "Be thorough when needed, concise when not. " +
            "Use markdown formatting (bold, lists, code blocks) where appropriate. " +
            "When actions are needed, include [ACTION: ...] tags. " +
            memory.buildContextSummary();
    }

    private void addMessage(String role, String text) {
        messages.add(new ChatMessage(role, text));
        adapter.notifyItemInserted(messages.size() - 1);
        chatRecycler.smoothScrollToPosition(messages.size() - 1);
    }

    private void showTyping(boolean show) {
        typingIndicator.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    // ─── Chat Message Model ───────────────────────────────────────────────

    static class ChatMessage {
        final String role;
        final String text;
        final long timestamp;

        ChatMessage(String role, String text) {
            this.role = role;
            this.text = text;
            this.timestamp = System.currentTimeMillis();
        }
    }

    // ─── RecyclerView Adapter ─────────────────────────────────────────────

    static class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ViewHolder> {
        private final List<ChatMessage> messages;

        ChatAdapter(List<ChatMessage> messages) {
            this.messages = messages;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_chat_message, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            ChatMessage msg = messages.get(position);
            holder.bind(msg);
        }

        @Override
        public int getItemCount() { return messages.size(); }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView roleText;
            TextView bodyText;
            View container;

            ViewHolder(View v) {
                super(v);
                roleText  = v.findViewById(R.id.msg_role);
                bodyText  = v.findViewById(R.id.msg_body);
                container = v.findViewById(R.id.msg_container);
            }

            void bind(ChatMessage msg) {
                boolean isUser = "user".equals(msg.role);
                roleText.setText(isUser ? "YOU" : "JARVIS");
                bodyText.setText(msg.text);

                // User messages: right-aligned cyan
                // JARVIS messages: left-aligned blue
                if (isUser) {
                    container.setBackgroundResource(R.drawable.bg_message_user);
                    roleText.setTextColor(0xFF00FFCC);
                } else {
                    container.setBackgroundResource(R.drawable.bg_message_jarvis);
                    roleText.setTextColor(0xFF0099FF);
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
