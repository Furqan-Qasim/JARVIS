package com.furqan.jarvis;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.PixelFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.Image;
import android.media.ImageReader;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.util.Base64;
import android.util.Log;
import android.util.Size;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * FloatingCameraService
 *
 * Creates a draggable, semi-transparent camera window that floats
 * always-on-top over any other app. JARVIS gets live camera access
 * for real-time visual analysis while continuing the conversation.
 */
public class FloatingCameraService extends Service {

    private static final String TAG = "FloatingCamera";
    private static final int NOTIF_ID = 1002;

    private WindowManager windowManager;
    private View floatingView;
    private SurfaceView surfaceView;
    private WindowManager.LayoutParams layoutParams;

    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private ImageReader imageReader;
    private CameraManager cameraManager;

    private final ExecutorService cameraExecutor = Executors.newSingleThreadExecutor();
    private boolean isFrontCamera = true;

    // Last captured frame for JARVIS to analyze
    private volatile Bitmap lastFrame;

    private final IBinder binder = new Binder();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if ("START_CAMERA".equals(action)) {
                isFrontCamera = intent.getBooleanExtra("front", true);
                startForegroundNotification();
                createFloatingWindow();
            } else if ("STOP_CAMERA".equals(action)) {
                stopSelf();
            } else if ("FLIP_CAMERA".equals(action)) {
                flipCamera();
            }
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return binder; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopCamera();
        if (floatingView != null && windowManager != null) {
            try { windowManager.removeView(floatingView); } catch (Exception ignored) {}
        }
    }

    // ─── Floating Window ─────────────────────────────────────────────────

    private void createFloatingWindow() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        // Build the overlay layout programmatically
        floatingView = buildOverlayLayout();

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        layoutParams = new WindowManager.LayoutParams(
            400, 300,       // width x height in pixels
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        layoutParams.gravity = Gravity.TOP | Gravity.END;
        layoutParams.x = 16;
        layoutParams.y = 200;

        windowManager.addView(floatingView, layoutParams);

        // Make it draggable
        makeDraggable(floatingView);

        // Start camera
        startCamera();
    }

    private View buildOverlayLayout() {
        FrameLayout container = new FrameLayout(this);
        container.setBackgroundColor(0x22000000);

        // Camera preview surface
        surfaceView = new SurfaceView(this);
        FrameLayout.LayoutParams svParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT);
        container.addView(surfaceView, svParams);

        // Blue holographic border
        View border = new View(this);
        border.setBackground(createHoloBorderDrawable());
        container.addView(border, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));

        // Header bar
        FrameLayout header = new FrameLayout(this);
        header.setBackgroundColor(0xAA001133);
        header.setPadding(8, 4, 8, 4);

        TextView title = new TextView(this);
        title.setText("JARVIS OPTICS");
        title.setTextColor(0xFF00CCFF);
        title.setTextSize(9f);
        title.setTypeface(android.graphics.Typeface.MONOSPACE);
        header.addView(title, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.START | Gravity.CENTER_VERTICAL));

        ImageButton closeBtn = new ImageButton(this);
        closeBtn.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        closeBtn.setBackgroundColor(0x00000000);
        closeBtn.setColorFilter(0xFF00CCFF);
        closeBtn.setOnClickListener(v -> stopSelf());
        header.addView(closeBtn, new FrameLayout.LayoutParams(32, 32, Gravity.END | Gravity.CENTER_VERTICAL));

        container.addView(header, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, 48, Gravity.TOP));

        // Scan line overlay for holographic effect
        TextView scanOverlay = new TextView(this);
        scanOverlay.setText("SCANNING");
        scanOverlay.setTextColor(0x5500CCFF);
        scanOverlay.setTextSize(8f);
        scanOverlay.setTypeface(android.graphics.Typeface.MONOSPACE);
        container.addView(scanOverlay, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.START));

        return container;
    }

    private android.graphics.drawable.Drawable createHoloBorderDrawable() {
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
        gd.setStroke(2, 0xAA00CCFF);
        gd.setColor(0x00000000);
        return gd;
    }

    private void makeDraggable(View view) {
        view.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private long touchDownTime;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = layoutParams.x;
                        initialY = layoutParams.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        touchDownTime = System.currentTimeMillis();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        layoutParams.x = initialX + (int)(initialTouchX - event.getRawX());
                        layoutParams.y = initialY + (int)(event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, layoutParams);
                        return true;
                }
                return false;
            }
        });
    }

    // ─── Camera2 ─────────────────────────────────────────────────────────

    @SuppressWarnings("MissingPermission")
    private void startCamera() {
        cameraManager = (CameraManager) getSystemService(CAMERA_SERVICE);
        try {
            String cameraId = getCameraId();
            if (cameraId == null) return;

            // ImageReader for frame capture (JARVIS analysis)
            imageReader = ImageReader.newInstance(640, 480, ImageFormat.JPEG, 2);
            imageReader.setOnImageAvailableListener(reader -> {
                Image image = reader.acquireLatestImage();
                if (image != null) {
                    ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buffer.remaining()];
                    buffer.get(bytes);
                    lastFrame = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    image.close();
                }
            }, null);

            cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(@NonNull CameraDevice camera) {
                    cameraDevice = camera;
                    createCaptureSession();
                }

                @Override
                public void onDisconnected(@NonNull CameraDevice camera) {
                    camera.close();
                    cameraDevice = null;
                }

                @Override
                public void onError(@NonNull CameraDevice camera, int error) {
                    Log.e(TAG, "Camera error: " + error);
                    camera.close();
                }
            }, null);

        } catch (CameraAccessException e) {
            Log.e(TAG, "Camera access error: " + e.getMessage());
        }
    }

    private void createCaptureSession() {
        if (cameraDevice == null) return;
        try {
            CaptureRequest.Builder previewBuilder = cameraDevice.createCaptureRequest(
                CameraDevice.TEMPLATE_PREVIEW);
            previewBuilder.addTarget(surfaceView.getHolder().getSurface());
            previewBuilder.addTarget(imageReader.getSurface());

            cameraDevice.createCaptureSession(
                Arrays.asList(surfaceView.getHolder().getSurface(), imageReader.getSurface()),
                new CameraCaptureSession.StateCallback() {
                    @Override
                    public void onConfigured(@NonNull CameraCaptureSession session) {
                        captureSession = session;
                        try {
                            previewBuilder.set(CaptureRequest.CONTROL_MODE,
                                CaptureRequest.CONTROL_MODE_AUTO);
                            session.setRepeatingRequest(previewBuilder.build(), null, null);
                        } catch (CameraAccessException e) {
                            Log.e(TAG, "Capture request failed: " + e.getMessage());
                        }
                    }

                    @Override
                    public void onConfigureFailed(@NonNull CameraCaptureSession session) {
                        Log.e(TAG, "Camera session config failed");
                    }
                }, null);
        } catch (CameraAccessException e) {
            Log.e(TAG, "Create session failed: " + e.getMessage());
        }
    }

    private String getCameraId() throws CameraAccessException {
        for (String id : cameraManager.getCameraIdList()) {
            CameraCharacteristics chars = cameraManager.getCameraCharacteristics(id);
            Integer facing = chars.get(CameraCharacteristics.LENS_FACING);
            if (facing != null) {
                if (isFrontCamera && facing == CameraCharacteristics.LENS_FACING_FRONT) return id;
                if (!isFrontCamera && facing == CameraCharacteristics.LENS_FACING_BACK) return id;
            }
        }
        return cameraManager.getCameraIdList().length > 0 ?
            cameraManager.getCameraIdList()[0] : null;
    }

    private void flipCamera() {
        isFrontCamera = !isFrontCamera;
        stopCamera();
        startCamera();
    }

    private void stopCamera() {
        if (captureSession != null) {
            try { captureSession.close(); } catch (Exception ignored) {}
            captureSession = null;
        }
        if (cameraDevice != null) {
            cameraDevice.close();
            cameraDevice = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
    }

    // ─── Frame Access for JARVIS Analysis ────────────────────────────────

    /**
     * Get current camera frame as Base64 JPEG for sending to Gemini
     */
    public String getCurrentFrameBase64() {
        if (lastFrame == null) return null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        lastFrame.compress(Bitmap.CompressFormat.JPEG, 80, baos);
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
    }

    // ─── Notification ─────────────────────────────────────────────────────

    private void startForegroundNotification() {
        Notification notif = new NotificationCompat.Builder(this, JarvisApp.CHANNEL_ID_SILENT)
            .setContentTitle("JARVIS Optics")
            .setContentText("Camera overlay active")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .setSilent(true)
            .build();
        startForeground(NOTIF_ID, notif);
    }
}
