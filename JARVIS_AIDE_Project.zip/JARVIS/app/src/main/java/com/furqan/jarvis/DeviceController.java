package com.furqan.jarvis;

import android.bluetooth.BluetoothAdapter;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.media.AudioManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Vibrator;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.util.Log;

import java.util.Calendar;
import java.util.List;

/**
 * DeviceController
 *
 * JARVIS's hands — controls every controllable aspect of Furqan's Android device.
 * Called from JarvisService when Gemini returns [ACTION: ...] commands.
 */
public class DeviceController {

    private static final String TAG = "DeviceController";

    private final Context context;
    private final AudioManager audioManager;

    public DeviceController(Context ctx) {
        this.context = ctx.getApplicationContext();
        this.audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
    }

    /**
     * Primary entry point — parses an action string and executes it
     * Format: "COMMAND_NAME | param1=value1 | param2=value2"
     */
    public String executeAction(String actionStr) {
        String[] parts = actionStr.split("\\|");
        if (parts.length == 0) return "Unknown action";

        String command = parts[0].trim();
        android.os.Bundle params = parseParams(parts);

        Log.d(TAG, "Executing: " + command + " with params: " + params);

        switch (command) {
            case "OPEN_APP":
                return openApp(params.getString("package", ""));
            case "SEND_WHATSAPP":
                return sendWhatsApp(params.getString("contact", ""),
                                    params.getString("message", ""));
            case "CALL":
                return callContact(params.getString("contact", ""));
            case "SEND_SMS":
                return sendSms(params.getString("contact", ""),
                               params.getString("message", ""));
            case "SET_VOLUME":
                return setVolume(params.getInt("level", 8));
            case "SET_BRIGHTNESS":
                return setBrightness(params.getInt("level", 128));
            case "TOGGLE_WIFI":
                return toggleWifi(params.getString("state", "on").equals("on"));
            case "TOGGLE_BLUETOOTH":
                return toggleBluetooth(params.getString("state", "on").equals("on"));
            case "TOGGLE_FLASHLIGHT":
                return toggleFlashlight(params.getString("state", "on").equals("on"));
            case "TOGGLE_DND":
                return toggleDnd(params.getString("state", "on").equals("on"));
            case "OPEN_CAMERA":
                return openCamera();
            case "PLAY_MUSIC":
                return playMusic(params.getString("query", ""));
            case "WEB_SEARCH":
                return webSearch(params.getString("query", ""));
            case "SET_ALARM":
                return setAlarm(params.getString("time", ""),
                               params.getString("label", "JARVIS Alarm"));
            case "ADD_CALENDAR":
                return addCalendarEvent(params.getString("title", ""),
                                        params.getString("date", ""),
                                        params.getString("time", ""));
            case "BUILD_MODE":
                return launchBuildMode();
            case "TEXT_MODE":
                return launchTextMode();
            case "CAMERA_OVERLAY":
                return launchCameraOverlay();
            case "SLEEP":
                return enterSleep();
            default:
                return "Command not recognized: " + command;
        }
    }

    private android.os.Bundle parseParams(String[] parts) {
        android.os.Bundle bundle = new android.os.Bundle();
        for (int i = 1; i < parts.length; i++) {
            String pair = parts[i].trim();
            int eq = pair.indexOf('=');
            if (eq > 0) {
                String key = pair.substring(0, eq).trim();
                String value = pair.substring(eq + 1).trim();
                bundle.putString(key, value);
                // Also try int
                try { bundle.putInt(key, Integer.parseInt(value)); } catch (Exception ignored) {}
            }
        }
        return bundle;
    }

    // ─── App Control ─────────────────────────────────────────────────────

    public String openApp(String packageName) {
        if (packageName.isEmpty()) return "No package specified";
        try {
            PackageManager pm = context.getPackageManager();
            Intent launch = pm.getLaunchIntentForPackage(packageName);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(launch);
                return "Opened " + packageName;
            } else {
                // Try fuzzy — search installed apps
                return searchAndOpenApp(packageName);
            }
        } catch (Exception e) {
            return "Failed to open app: " + e.getMessage();
        }
    }

    private String searchAndOpenApp(String query) {
        PackageManager pm = context.getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN, null);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);

        String queryLower = query.toLowerCase();
        for (ResolveInfo ri : apps) {
            String label = ri.loadLabel(pm).toString().toLowerCase();
            if (label.contains(queryLower) || queryLower.contains(label)) {
                Intent launch = new Intent(Intent.ACTION_MAIN);
                launch.setClassName(ri.activityInfo.packageName, ri.activityInfo.name);
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(launch);
                return "Opened " + ri.loadLabel(pm);
            }
        }
        return "App not found: " + query;
    }

    // ─── WhatsApp ─────────────────────────────────────────────────────────

    public String sendWhatsApp(String contactName, String message) {
        // First try to find contact number
        String phone = findContactPhone(contactName);
        if (phone == null) {
            // Open WhatsApp and let accessibility service handle it
            Intent wa = new Intent(Intent.ACTION_MAIN);
            wa.setPackage("com.whatsapp");
            wa.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(wa);
            // Signal accessibility service
            broadcastAccessibilityTask("WHATSAPP_CONTACT",
                "contact=" + contactName + "|message=" + message);
            return "Opening WhatsApp — searching for " + contactName;
        }

        // Clean phone number
        phone = phone.replaceAll("[^\\d+]", "");
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("https://api.whatsapp.com/send?phone=" +
                phone + "&text=" + Uri.encode(message)));
            intent.setPackage("com.whatsapp");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return "WhatsApp message prepared for " + contactName;
        } catch (Exception e) {
            return "WhatsApp error: " + e.getMessage();
        }
    }

    // ─── Contacts ────────────────────────────────────────────────────────

    private String findContactPhone(String name) {
        try {
            Cursor cursor = context.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                },
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                new String[]{"%" + name + "%"},
                null);

            if (cursor != null && cursor.moveToFirst()) {
                String phone = cursor.getString(0);
                cursor.close();
                return phone;
            }
        } catch (Exception e) {
            Log.e(TAG, "Contact lookup failed: " + e.getMessage());
        }
        return null;
    }

    // ─── Calling ─────────────────────────────────────────────────────────

    public String callContact(String name) {
        String phone = findContactPhone(name);
        if (phone == null) {
            // Open dialer and let user complete
            Intent dial = new Intent(Intent.ACTION_DIAL);
            dial.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(dial);
            return "Could not find " + name + " — opening dialer";
        }
        try {
            Intent call = new Intent(Intent.ACTION_CALL);
            call.setData(Uri.parse("tel:" + phone));
            call.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(call);
            return "Calling " + name;
        } catch (Exception e) {
            return "Call failed: " + e.getMessage();
        }
    }

    // ─── SMS ─────────────────────────────────────────────────────────────

    public String sendSms(String contact, String message) {
        String phone = findContactPhone(contact);
        if (phone == null) phone = contact; // try as raw number
        try {
            Intent sms = new Intent(Intent.ACTION_SENDTO);
            sms.setData(Uri.parse("smsto:" + phone));
            sms.putExtra("sms_body", message);
            sms.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(sms);
            return "SMS prepared for " + contact;
        } catch (Exception e) {
            return "SMS failed: " + e.getMessage();
        }
    }

    // ─── Volume ──────────────────────────────────────────────────────────

    public String setVolume(int level) {
        int maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int vol = Math.max(0, Math.min(level, maxVol));
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, vol,
            AudioManager.FLAG_SHOW_UI);
        return "Volume set to " + vol + "/" + maxVol;
    }

    public String setVolumePercent(int percent) {
        int maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int vol = (int) (maxVol * percent / 100.0f);
        return setVolume(vol);
    }

    // ─── Brightness ──────────────────────────────────────────────────────

    public String setBrightness(int level) {
        try {
            Settings.System.putInt(context.getContentResolver(),
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
            Settings.System.putInt(context.getContentResolver(),
                Settings.System.SCREEN_BRIGHTNESS,
                Math.max(0, Math.min(255, level)));
            return "Brightness set to " + level;
        } catch (Exception e) {
            return "Brightness control requires WRITE_SETTINGS permission";
        }
    }

    // ─── WiFi ────────────────────────────────────────────────────────────

    @SuppressWarnings("deprecation")
    public String toggleWifi(boolean enable) {
        try {
            WifiManager wm = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                wm.setWifiEnabled(enable);
                return "WiFi " + (enable ? "enabled" : "disabled");
            } else {
                // Android 10+ requires user to toggle manually or use Settings panel
                Intent panel = new Intent(Settings.Panel.ACTION_WIFI);
                panel.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(panel);
                return "Opening WiFi settings panel";
            }
        } catch (Exception e) {
            return "WiFi toggle failed: " + e.getMessage();
        }
    }

    // ─── Bluetooth ───────────────────────────────────────────────────────

    @SuppressWarnings("MissingPermission")
    public String toggleBluetooth(boolean enable) {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) return "No Bluetooth adapter found";
            if (enable) adapter.enable();
            else adapter.disable();
            return "Bluetooth " + (enable ? "enabled" : "disabled");
        } catch (Exception e) {
            return "Bluetooth toggle failed: " + e.getMessage();
        }
    }

    // ─── Flashlight ──────────────────────────────────────────────────────

    private android.hardware.camera2.CameraManager cameraManager;
    private String flashCameraId;
    private boolean flashOn = false;

    public String toggleFlashlight(boolean enable) {
        try {
            if (cameraManager == null) {
                cameraManager = (android.hardware.camera2.CameraManager)
                    context.getSystemService(Context.CAMERA_SERVICE);
                flashCameraId = cameraManager.getCameraIdList()[0];
            }
            cameraManager.setTorchMode(flashCameraId, enable);
            flashOn = enable;
            return "Flashlight " + (enable ? "on" : "off");
        } catch (Exception e) {
            return "Flashlight failed: " + e.getMessage();
        }
    }

    // ─── Do Not Disturb ──────────────────────────────────────────────────

    public String toggleDnd(boolean enable) {
        try {
            android.app.NotificationManager nm =
                (android.app.NotificationManager) context.getSystemService(
                    Context.NOTIFICATION_SERVICE);
            if (nm.isNotificationPolicyAccessGranted()) {
                nm.setInterruptionFilter(enable ?
                    android.app.NotificationManager.INTERRUPTION_FILTER_NONE :
                    android.app.NotificationManager.INTERRUPTION_FILTER_ALL);
                return "Do Not Disturb " + (enable ? "enabled" : "disabled");
            } else {
                Intent dnd = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
                dnd.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(dnd);
                return "Opening DND settings — please grant access";
            }
        } catch (Exception e) {
            return "DND toggle failed: " + e.getMessage();
        }
    }

    // ─── Camera ──────────────────────────────────────────────────────────

    public String openCamera() {
        Intent cam = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        cam.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(cam);
        return "Camera opened";
    }

    // ─── Music ───────────────────────────────────────────────────────────

    public String playMusic(String query) {
        // Try Spotify first, then YouTube Music, then generic
        String[] musicApps = {
            "com.spotify.music",
            "com.google.android.apps.youtube.music",
            "com.youtube.music"
        };

        PackageManager pm = context.getPackageManager();
        for (String pkg : musicApps) {
            try {
                pm.getPackageInfo(pkg, 0);
                Intent launch = pm.getLaunchIntentForPackage(pkg);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(launch);
                    // Signal accessibility to search
                    if (!query.isEmpty()) {
                        broadcastAccessibilityTask("MUSIC_SEARCH",
                            "package=" + pkg + "|query=" + query);
                    }
                    return "Opening music — searching for: " + query;
                }
            } catch (PackageManager.NameNotFoundException ignored) {}
        }

        // Fall back to YouTube
        Intent yt = new Intent(Intent.ACTION_SEARCH);
        yt.setPackage("com.google.android.youtube");
        yt.putExtra("query", query);
        yt.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(yt);
            return "Searching YouTube for: " + query;
        } catch (Exception e) {
            return "No music app found";
        }
    }

    // ─── Web Search ──────────────────────────────────────────────────────

    public String webSearch(String query) {
        Intent search = new Intent(Intent.ACTION_WEB_SEARCH);
        search.putExtra(android.app.SearchManager.QUERY, query);
        search.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(search);
        return "Searching for: " + query;
    }

    // ─── Alarm ───────────────────────────────────────────────────────────

    public String setAlarm(String timeStr, String label) {
        try {
            String[] parts = timeStr.split(":");
            int hour = Integer.parseInt(parts[0]);
            int minute = parts.length > 1 ? Integer.parseInt(parts[1]) : 0;

            Intent alarm = new Intent(AlarmClock.ACTION_SET_ALARM);
            alarm.putExtra(AlarmClock.EXTRA_HOUR, hour);
            alarm.putExtra(AlarmClock.EXTRA_MINUTES, minute);
            alarm.putExtra(AlarmClock.EXTRA_MESSAGE, label);
            alarm.putExtra(AlarmClock.EXTRA_SKIP_UI, false);
            alarm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(alarm);
            return String.format("Alarm set for %02d:%02d — %s", hour, minute, label);
        } catch (Exception e) {
            return "Failed to set alarm: " + e.getMessage();
        }
    }

    // ─── Calendar ────────────────────────────────────────────────────────

    public String addCalendarEvent(String title, String date, String time) {
        try {
            long startMillis;
            Calendar cal = Calendar.getInstance();
            if (!date.isEmpty()) {
                String[] dateParts = date.split("-");
                cal.set(Calendar.YEAR, Integer.parseInt(dateParts[0]));
                cal.set(Calendar.MONTH, Integer.parseInt(dateParts[1]) - 1);
                cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dateParts[2]));
            }
            if (!time.isEmpty()) {
                String[] timeParts = time.split(":");
                cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(timeParts[0]));
                cal.set(Calendar.MINUTE, Integer.parseInt(timeParts[1]));
            }
            startMillis = cal.getTimeInMillis();

            Intent intent = new Intent(Intent.ACTION_INSERT)
                .setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, startMillis + 3600000L)
                .putExtra(CalendarContract.Events.TITLE, title);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return "Calendar event created: " + title;
        } catch (Exception e) {
            return "Calendar event failed: " + e.getMessage();
        }
    }

    // ─── Mode Switching ──────────────────────────────────────────────────

    public String launchBuildMode() {
        Intent intent = new Intent(context, BuildModeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        return "Entering Build Mode";
    }

    public String launchTextMode() {
        Intent intent = new Intent(context, TextModeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        return "Switching to Text Mode";
    }

    public String launchCameraOverlay() {
        Intent intent = new Intent(context, FloatingCameraService.class);
        intent.setAction("START_CAMERA");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
        return "Camera overlay activated";
    }

    public String enterSleep() {
        Intent intent = new Intent(context, JarvisService.class);
        intent.setAction("com.furqan.jarvis.SLEEP");
        context.startService(intent);
        return "Entering standby mode";
    }

    // ─── Utility ─────────────────────────────────────────────────────────

    private void broadcastAccessibilityTask(String taskType, String params) {
        Intent intent = new Intent("com.furqan.jarvis.ACCESSIBILITY_TASK");
        intent.putExtra("task_type", taskType);
        intent.putExtra("task_params", params);
        context.sendBroadcast(intent);
    }

    public void vibrate(long ms) {
        Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null) v.vibrate(ms);
    }
}
