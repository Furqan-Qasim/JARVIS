package com.furqan.jarvis;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

/**
 * JarvisAccessibilityService
 *
 * JARVIS's ability to see and control any app on the device.
 * Handles complex multi-step automations:
 * - WhatsApp messaging (find contact → type → send)
 * - YouTube control (search → play → speed)
 * - Any UI automation via text input, clicking, scrolling
 *
 * Enable via: Settings → Accessibility → Installed Apps → JARVIS
 */
public class JarvisAccessibilityService extends AccessibilityService {

    private static final String TAG = "JarvisA11y";

    private String currentPackage = "";
    private BroadcastReceiver taskReceiver;

    // Pending task for multi-step automations
    private String pendingTaskType = null;
    private Bundle pendingTaskParams = null;
    private int taskStep = 0;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        Log.d(TAG, "Accessibility service connected");
        JarvisApp.accessibilityService = this;

        // Listen for task broadcasts from DeviceController
        taskReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String taskType = intent.getStringExtra("task_type");
                String taskParams = intent.getStringExtra("task_params");
                Log.d(TAG, "Task received: " + taskType + " | " + taskParams);
                startTask(taskType, taskParams);
            }
        };
        IntentFilter filter = new IntentFilter("com.furqan.jarvis.ACCESSIBILITY_TASK");
        registerReceiver(taskReceiver, filter);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        if (event.getPackageName() != null) {
            currentPackage = event.getPackageName().toString();
        }

        // Handle pending multi-step tasks
        if (pendingTaskType != null) {
            processTaskStep(event);
        }
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "Accessibility service interrupted");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        JarvisApp.accessibilityService = null;
        if (taskReceiver != null) {
            try { unregisterReceiver(taskReceiver); } catch (Exception ignored) {}
        }
    }

    // ─── Task Management ─────────────────────────────────────────────────

    private void startTask(String taskType, String paramsStr) {
        pendingTaskType = taskType;
        pendingTaskParams = parseParams(paramsStr);
        taskStep = 0;
        Log.d(TAG, "Starting task: " + taskType + " step 0");
    }

    private void processTaskStep(AccessibilityEvent event) {
        if (pendingTaskType == null) return;

        switch (pendingTaskType) {
            case "WHATSAPP_CONTACT":
                handleWhatsAppTask(event);
                break;
            case "MUSIC_SEARCH":
                handleMusicSearchTask(event);
                break;
            case "YOUTUBE_SEARCH":
                handleYouTubeTask(event);
                break;
        }
    }

    // ─── WhatsApp Automation ─────────────────────────────────────────────

    private void handleWhatsAppTask(AccessibilityEvent event) {
        String contactName = pendingTaskParams.getString("contact", "");
        String message = pendingTaskParams.getString("message", "");

        switch (taskStep) {
            case 0:
                // Look for search bar in WhatsApp
                if (currentPackage.contains("whatsapp")) {
                    new android.os.Handler(android.os.Looper.getMainLooper())
                        .postDelayed(() -> {
                            AccessibilityNodeInfo search = findNodeByText("Search");
                            if (search == null) search = findNodeById("com.whatsapp:id/search_btn");
                            if (search != null) {
                                search.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                                taskStep = 1;
                            }
                        }, 1000);
                }
                break;

            case 1:
                // Type contact name in search
                new android.os.Handler(android.os.Looper.getMainLooper())
                    .postDelayed(() -> {
                        AccessibilityNodeInfo searchField = findFocusedInput();
                        if (searchField != null) {
                            typeText(searchField, contactName);
                            taskStep = 2;
                        }
                    }, 500);
                break;

            case 2:
                // Wait for search results and click the contact
                new android.os.Handler(android.os.Looper.getMainLooper())
                    .postDelayed(() -> {
                        AccessibilityNodeInfo contact = findNodeByText(contactName);
                        if (contact != null) {
                            // Click on contact row
                            AccessibilityNodeInfo parent = contact.getParent();
                            while (parent != null && !parent.isClickable()) {
                                parent = parent.getParent();
                            }
                            if (parent != null) {
                                parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                            } else {
                                contact.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                            }
                            taskStep = 3;
                        }
                    }, 1000);
                break;

            case 3:
                // Find message input and type
                new android.os.Handler(android.os.Looper.getMainLooper())
                    .postDelayed(() -> {
                        AccessibilityNodeInfo msgInput = findNodeById(
                            "com.whatsapp:id/entry");
                        if (msgInput == null) msgInput = findNodeByContentDesc("Type a message");
                        if (msgInput == null) msgInput = findFocusedInput();
                        if (msgInput != null) {
                            msgInput.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                            typeText(msgInput, message);
                            taskStep = 4;
                        }
                    }, 1500);
                break;

            case 4:
                // Click send button
                new android.os.Handler(android.os.Looper.getMainLooper())
                    .postDelayed(() -> {
                        AccessibilityNodeInfo sendBtn = findNodeById("com.whatsapp:id/send");
                        if (sendBtn == null) sendBtn = findNodeByContentDesc("Send");
                        if (sendBtn != null) {
                            sendBtn.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                            Log.d(TAG, "Message sent!");
                            pendingTaskType = null;
                        }
                    }, 500);
                break;
        }
    }

    // ─── YouTube Automation ──────────────────────────────────────────────

    private void handleYouTubeTask(AccessibilityEvent event) {
        String query = pendingTaskParams.getString("query", "");
        switch (taskStep) {
            case 0:
                if (currentPackage.contains("youtube")) {
                    new android.os.Handler(android.os.Looper.getMainLooper())
                        .postDelayed(() -> {
                            AccessibilityNodeInfo searchBtn = findNodeByContentDesc("Search");
                            if (searchBtn != null) {
                                searchBtn.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                                taskStep = 1;
                            }
                        }, 1000);
                }
                break;
            case 1:
                new android.os.Handler(android.os.Looper.getMainLooper())
                    .postDelayed(() -> {
                        AccessibilityNodeInfo searchField = findFocusedInput();
                        if (searchField != null) {
                            typeText(searchField, query);
                            performGlobalAction(GLOBAL_ACTION_BACK); // dismiss keyboard
                            taskStep = 2;
                            pendingTaskType = null; // let user take over from here
                        }
                    }, 800);
                break;
        }
    }

    // ─── Music Search Automation ─────────────────────────────────────────

    private void handleMusicSearchTask(AccessibilityEvent event) {
        String query = pendingTaskParams.getString("query", "");
        if (taskStep == 0 && !currentPackage.isEmpty()) {
            new android.os.Handler(android.os.Looper.getMainLooper())
                .postDelayed(() -> {
                    AccessibilityNodeInfo search = findNodeByContentDesc("Search");
                    if (search != null) {
                        search.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        taskStep = 1;
                    }
                }, 1200);
        } else if (taskStep == 1) {
            new android.os.Handler(android.os.Looper.getMainLooper())
                .postDelayed(() -> {
                    AccessibilityNodeInfo input = findFocusedInput();
                    if (input != null) {
                        typeText(input, query);
                        pendingTaskType = null;
                    }
                }, 600);
        }
    }

    // ─── Node Finders ────────────────────────────────────────────────────

    private AccessibilityNodeInfo findNodeByText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return null;
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(text);
        return (nodes != null && !nodes.isEmpty()) ? nodes.get(0) : null;
    }

    private AccessibilityNodeInfo findNodeById(String id) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return null;
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(id);
        return (nodes != null && !nodes.isEmpty()) ? nodes.get(0) : null;
    }

    private AccessibilityNodeInfo findNodeByContentDesc(String desc) {
        return findNodeByContentDescRecursive(getRootInActiveWindow(), desc);
    }

    private AccessibilityNodeInfo findNodeByContentDescRecursive(
            AccessibilityNodeInfo node, String desc) {
        if (node == null) return null;
        if (desc.equalsIgnoreCase(
            node.getContentDescription() != null ?
            node.getContentDescription().toString() : "")) {
            return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo result =
                findNodeByContentDescRecursive(node.getChild(i), desc);
            if (result != null) return result;
        }
        return null;
    }

    private AccessibilityNodeInfo findFocusedInput() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return null;
        return root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
    }

    // ─── Actions ─────────────────────────────────────────────────────────

    private void typeText(AccessibilityNodeInfo node, String text) {
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    /**
     * Perform a tap gesture at screen coordinates
     */
    public void performTap(float x, float y) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            Path path = new Path();
            path.moveTo(x, y);
            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 50));
            dispatchGesture(builder.build(), null, null);
        }
    }

    /**
     * Perform a swipe gesture
     */
    public void performSwipe(float x1, float y1, float x2, float y2) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            Path path = new Path();
            path.moveTo(x1, y1);
            path.lineTo(x2, y2);
            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 300));
            dispatchGesture(builder.build(), null, null);
        }
    }

    /**
     * Read all text visible on screen — useful for JARVIS to understand current state
     */
    public String readScreen() {
        StringBuilder sb = new StringBuilder();
        readNodeText(getRootInActiveWindow(), sb);
        return sb.toString();
    }

    private void readNodeText(AccessibilityNodeInfo node, StringBuilder sb) {
        if (node == null) return;
        if (node.getText() != null) sb.append(node.getText()).append(" ");
        if (node.getContentDescription() != null) sb.append(node.getContentDescription()).append(" ");
        for (int i = 0; i < node.getChildCount(); i++) {
            readNodeText(node.getChild(i), sb);
        }
    }

    // ─── Utilities ───────────────────────────────────────────────────────

    private Bundle parseParams(String paramsStr) {
        Bundle bundle = new Bundle();
        if (paramsStr == null || paramsStr.isEmpty()) return bundle;
        String[] pairs = paramsStr.split("\\|");
        for (String pair : pairs) {
            int eq = pair.indexOf('=');
            if (eq > 0) {
                bundle.putString(pair.substring(0, eq).trim(),
                                 pair.substring(eq + 1).trim());
            }
        }
        return bundle;
    }

    public String getCurrentPackage() { return currentPackage; }
}
