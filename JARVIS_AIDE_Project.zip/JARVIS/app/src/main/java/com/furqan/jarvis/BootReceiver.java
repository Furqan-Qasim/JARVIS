package com.furqan.jarvis;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

/**
 * BootReceiver
 *
 * Catches BOOT_COMPLETED broadcast and restarts JarvisService.
 * JARVIS survives device reboots.
 */
public class BootReceiver extends BroadcastReceiver {

    private static final String TAG = "BootReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) ||
            "android.intent.action.QUICKBOOT_POWERON".equals(action) ||
            "com.htc.intent.action.QUICKBOOT_POWERON".equals(action)) {

            Log.d(TAG, "Boot completed — starting JARVIS");

            // Check if user has set up JARVIS (has API key)
            MemoryManager memory = MemoryManager.getInstance(context);
            if (!memory.hasApiKey()) {
                Log.d(TAG, "No API key — skipping autostart");
                return;
            }

            Intent serviceIntent = new Intent(context, JarvisService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent);
            } else {
                context.startService(serviceIntent);
            }
            Log.d(TAG, "JARVIS service started after boot");
        }
    }
}
