package com.furqan.jarvis;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * PermissionActivity — First-Run Setup & Settings
 *
 * Guides Furqan through:
 * 1. Entering Gemini API key
 * 2. Granting all required permissions (with JARVIS-voiced explanation)
 * 3. Enabling Accessibility Service
 * 4. Enabling Overlay permission
 * 5. Battery optimization exemption
 */
public class PermissionActivity extends AppCompatActivity {

    private EditText apiKeyInput;
    private Button btnSaveKey;
    private Button btnMicPerm;
    private Button btnContactsPerm;
    private Button btnStoragePerm;
    private Button btnOverlayPerm;
    private Button btnAccessibility;
    private Button btnBatteryOptim;
    private Button btnAllDone;
    private TextView statusApiKey;
    private TextView statusMic;
    private TextView statusContacts;
    private TextView statusStorage;
    private TextView statusOverlay;
    private TextView statusAccessibility;
    private TextView statusBattery;

    private MemoryManager memory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);
        memory = MemoryManager.getInstance(this);

        initViews();
        setupClickHandlers();
        refreshStatusIndicators();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatusIndicators();
    }

    private void initViews() {
        apiKeyInput         = findViewById(R.id.api_key_input);
        btnSaveKey          = findViewById(R.id.btn_save_key);
        btnMicPerm          = findViewById(R.id.btn_mic_perm);
        btnContactsPerm     = findViewById(R.id.btn_contacts_perm);
        btnStoragePerm      = findViewById(R.id.btn_storage_perm);
        btnOverlayPerm      = findViewById(R.id.btn_overlay_perm);
        btnAccessibility    = findViewById(R.id.btn_accessibility);
        btnBatteryOptim     = findViewById(R.id.btn_battery_optim);
        btnAllDone          = findViewById(R.id.btn_all_done);
        statusApiKey        = findViewById(R.id.status_api_key);
        statusMic           = findViewById(R.id.status_mic);
        statusContacts      = findViewById(R.id.status_contacts);
        statusStorage       = findViewById(R.id.status_storage);
        statusOverlay       = findViewById(R.id.status_overlay);
        statusAccessibility = findViewById(R.id.status_accessibility);
        statusBattery       = findViewById(R.id.status_battery);

        // Pre-fill API key if saved
        if (memory.hasApiKey()) {
            apiKeyInput.setText(memory.getApiKey());
        }
    }

    private void setupClickHandlers() {
        btnSaveKey.setOnClickListener(v -> {
            String key = apiKeyInput.getText().toString().trim();
            if (key.isEmpty() || key.length() < 20) {
                Toast.makeText(this, "Please enter a valid API key", Toast.LENGTH_SHORT).show();
                return;
            }
            memory.saveApiKey(key);
            memory.setLaunched();
            refreshStatusIndicators();
            Toast.makeText(this, "API key saved, sir.", Toast.LENGTH_SHORT).show();
        });

        btnMicPerm.setOnClickListener(v ->
            ActivityCompat.requestPermissions(this,
                new String[]{
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.WRITE_CONTACTS,
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.READ_SMS,
                    Manifest.permission.READ_CALL_LOG,
                    Manifest.permission.CAMERA,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.READ_CALENDAR,
                    Manifest.permission.WRITE_CALENDAR,
                }, 101));

        btnStoragePerm.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } catch (Exception e) {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                    startActivity(intent);
                }
            } else {
                ActivityCompat.requestPermissions(this,
                    new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    }, 102);
            }
        });

        btnOverlayPerm.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        });

        btnAccessibility.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        btnBatteryOptim.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        });

        btnAllDone.setOnClickListener(v -> {
            if (!memory.hasApiKey()) {
                Toast.makeText(this, "Please save your API key first", Toast.LENGTH_SHORT).show();
                return;
            }
            // Launch MainActivity and start service
            Intent main = new Intent(this, MainActivity.class);
            main.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(main);
            finish();
        });
    }

    private void refreshStatusIndicators() {
        // API Key
        setStatus(statusApiKey, memory.hasApiKey());

        // Microphone
        setStatus(statusMic,
            checkPerm(Manifest.permission.RECORD_AUDIO) &&
            checkPerm(Manifest.permission.READ_CONTACTS));

        // Contacts / SMS
        setStatus(statusContacts,
            checkPerm(Manifest.permission.CALL_PHONE) &&
            checkPerm(Manifest.permission.SEND_SMS));

        // Storage
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            setStatus(statusStorage,
                android.os.Environment.isExternalStorageManager());
        } else {
            setStatus(statusStorage,
                checkPerm(Manifest.permission.WRITE_EXTERNAL_STORAGE));
        }

        // Overlay
        boolean overlay = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
            Settings.canDrawOverlays(this);
        setStatus(statusOverlay, overlay);

        // Accessibility — check if our service is running
        setStatus(statusAccessibility, isAccessibilityEnabled());

        // Battery optimization
        android.os.PowerManager pm = (android.os.PowerManager)
            getSystemService(POWER_SERVICE);
        boolean batteryOk = pm.isIgnoringBatteryOptimizations(getPackageName());
        setStatus(statusBattery, batteryOk);
    }

    private void setStatus(TextView tv, boolean ok) {
        tv.setText(ok ? "✓  GRANTED" : "✗  REQUIRED");
        tv.setTextColor(ok ? 0xFF00FF88 : 0xFFFF4444);
    }

    private boolean checkPerm(String perm) {
        return ContextCompat.checkSelfPermission(this, perm) ==
            PackageManager.PERMISSION_GRANTED;
    }

    private boolean isAccessibilityEnabled() {
        try {
            int enabled = Settings.Secure.getInt(getContentResolver(),
                Settings.Secure.ACCESSIBILITY_ENABLED, 0);
            if (enabled == 0) return false;
            String services = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return services != null &&
                services.contains(getPackageName() + "/" +
                    JarvisAccessibilityService.class.getName());
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
            String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refreshStatusIndicators();
    }
}
