package com.furqan.jarvis;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * JARVIS Memory Manager
 * Stores conversation history, preferences, and learned behaviors
 * All data is persisted locally in SharedPreferences (JSON-serialized)
 */
public class MemoryManager {

    private static final String PREFS_NAME      = "jarvis_memory";
    private static final String KEY_API_KEY      = "gemini_api_key";
    private static final String KEY_HISTORY      = "conversation_history";
    private static final String KEY_PREFS        = "user_preferences";
    private static final String KEY_FIRST_LAUNCH = "first_launch";
    private static final String KEY_VOICE_NAME   = "voice_name";

    // Max history entries to keep (to avoid SharedPrefs bloat)
    private static final int MAX_HISTORY = 200;

    private final SharedPreferences prefs;
    private final Gson gson;
    private List<MemoryEntry> historyCache;

    public static class MemoryEntry {
        public String role;      // "user" or "model"
        public String text;
        public long timestamp;

        public MemoryEntry(String role, String text) {
            this.role = role;
            this.text = text;
            this.timestamp = System.currentTimeMillis();
        }
    }

    public static class UserPreference {
        public String key;
        public String value;
        public long timestamp;

        public UserPreference(String key, String value) {
            this.key = key;
            this.value = value;
            this.timestamp = System.currentTimeMillis();
        }
    }

    private static MemoryManager instance;

    public static MemoryManager getInstance(Context ctx) {
        if (instance == null) {
            instance = new MemoryManager(ctx.getApplicationContext());
        }
        return instance;
    }

    private MemoryManager(Context ctx) {
        prefs = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
        loadHistory();
    }

    // ─── API Key ────────────────────────────────────────────────────

    public void saveApiKey(String key) {
        prefs.edit().putString(KEY_API_KEY, key.trim()).apply();
    }

    public String getApiKey() {
        return prefs.getString(KEY_API_KEY, "");
    }

    public boolean hasApiKey() {
        String key = getApiKey();
        return key != null && !key.isEmpty();
    }

    // ─── Voice Name ─────────────────────────────────────────────────

    public void saveVoiceName(String name) {
        prefs.edit().putString(KEY_VOICE_NAME, name).apply();
    }

    public String getVoiceName() {
        // Charon = deep calm male voice in Gemini
        return prefs.getString(KEY_VOICE_NAME, "Charon");
    }

    // ─── First Launch ───────────────────────────────────────────────

    public boolean isFirstLaunch() {
        return prefs.getBoolean(KEY_FIRST_LAUNCH, true);
    }

    public void setLaunched() {
        prefs.edit().putBoolean(KEY_FIRST_LAUNCH, false).apply();
    }

    // ─── Conversation History ────────────────────────────────────────

    private void loadHistory() {
        String json = prefs.getString(KEY_HISTORY, "[]");
        Type type = new TypeToken<List<MemoryEntry>>() {}.getType();
        historyCache = gson.fromJson(json, type);
        if (historyCache == null) historyCache = new ArrayList<>();
    }

    public void addEntry(String role, String text) {
        historyCache.add(new MemoryEntry(role, text));
        // Trim if too long
        while (historyCache.size() > MAX_HISTORY) {
            historyCache.remove(0);
        }
        saveHistory();
    }

    private void saveHistory() {
        prefs.edit().putString(KEY_HISTORY, gson.toJson(historyCache)).apply();
    }

    public List<MemoryEntry> getRecentHistory(int count) {
        int start = Math.max(0, historyCache.size() - count);
        return new ArrayList<>(historyCache.subList(start, historyCache.size()));
    }

    public List<MemoryEntry> getFullHistory() {
        return new ArrayList<>(historyCache);
    }

    public void clearHistory() {
        historyCache.clear();
        saveHistory();
    }

    /**
     * Builds a context string summarizing recent interactions
     * Injected into system prompt to give JARVIS memory
     */
    public String buildContextSummary() {
        if (historyCache.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        sb.append("\n\n=== MEMORY OF RECENT INTERACTIONS ===\n");
        List<MemoryEntry> recent = getRecentHistory(30);
        SimpleDateFormat sdf = new SimpleDateFormat("MMM d, HH:mm", Locale.UK);
        for (MemoryEntry e : recent) {
            String prefix = e.role.equals("user") ? "Furqan" : "JARVIS";
            sb.append("[").append(sdf.format(new Date(e.timestamp))).append("] ")
              .append(prefix).append(": ").append(e.text).append("\n");
        }
        sb.append("=== END MEMORY ===\n");
        return sb.toString();
    }

    // ─── User Preferences ────────────────────────────────────────────

    public void savePreference(String key, String value) {
        String prefKey = "pref_" + key;
        prefs.edit().putString(prefKey, value).apply();
    }

    public String getPreference(String key, String defaultValue) {
        return prefs.getString("pref_" + key, defaultValue);
    }

    /**
     * Learn and store a user preference from conversation context
     * e.g., "I always want 1.5x speed on YouTube" → savePreference("youtube_speed", "1.5")
     */
    public void learnPreference(String key, String value) {
        savePreference(key, value);
        // Also log it in history for context
        addEntry("system", "Learned preference: " + key + " = " + value);
    }
}
