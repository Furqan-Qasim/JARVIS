package com.furqan.jarvis;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * HotwordDetector
 *
 * Continuously listens for "Hey Jarvis" using Android's SpeechRecognizer.
 * Runs in a low-power restart loop — when one recognition session ends,
 * it immediately starts another. This is the standard approach for on-device
 * hotword detection without requiring a third-party library.
 *
 * When the hotword is detected, it calls onHotwordDetected().
 * When wakeword deactivation phrases are detected, it calls onSleepDetected().
 */
public class HotwordDetector {

    private static final String TAG = "HotwordDetector";

    // Wake words
    private static final String[] WAKE_WORDS = {
        "hey jarvis", "jarvis", "hey davis", "hey travis" // fuzzy matches
    };

    // Sleep words — return to standby
    private static final String[] SLEEP_WORDS = {
        "jarvis log off", "jarvis go to sleep", "jarvis sleep",
        "jarvis standby", "jarvis power down", "log off jarvis",
        "goodnight jarvis", "jarvis shut down"
    };

    private final Context context;
    private SpeechRecognizer speechRecognizer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean isActive = false;
    private boolean isListeningForHotword = true; // true = hotword mode, false = conversation mode

    public interface HotwordCallback {
        void onHotwordDetected();
        void onSleepDetected();
        void onPartialResult(String partial);
    }

    private HotwordCallback callback;
    private static final int RESTART_DELAY_MS = 300;
    private static final int ERROR_RESTART_MS = 1500;

    public HotwordDetector(Context context) {
        this.context = context.getApplicationContext();
    }

    public void setCallback(HotwordCallback cb) {
        this.callback = cb;
    }

    public void start() {
        if (isActive) return;
        isActive = true;
        handler.post(this::startListening);
    }

    public void stop() {
        isActive = false;
        handler.removeCallbacksAndMessages(null);
        if (speechRecognizer != null) {
            try {
                speechRecognizer.stopListening();
                speechRecognizer.destroy();
            } catch (Exception ignored) {}
            speechRecognizer = null;
        }
    }

    /**
     * Switch between hotword-only mode and sleep-word mode
     * In hotword mode: only wake on "Hey Jarvis"
     * In sleep mode: monitor for "Jarvis log off" etc.
     */
    public void setHotwordMode(boolean hotwordOnly) {
        this.isListeningForHotword = hotwordOnly;
    }

    private void startListening() {
        if (!isActive) return;
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.w(TAG, "Speech recognition not available");
            handler.postDelayed(this::startListening, 5000);
            return;
        }

        if (speechRecognizer != null) {
            try { speechRecognizer.destroy(); } catch (Exception ignored) {}
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {

            @Override
            public void onReadyForSpeech(Bundle params) {
                Log.d(TAG, "Ready for speech (hotword mode: " + isListeningForHotword + ")");
            }

            @Override
            public void onBeginningOfSpeech() {}

            @Override
            public void onRmsChanged(float rmsdB) {
                // Could use for low-level voice activity detection
            }

            @Override
            public void onBufferReceived(byte[] buffer) {}

            @Override
            public void onEndOfSpeech() {}

            @Override
            public void onError(int error) {
                // Most errors are just timeouts or no speech — restart quietly
                int delay = (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                             error == SpeechRecognizer.ERROR_NETWORK) ?
                             ERROR_RESTART_MS : RESTART_DELAY_MS;
                if (isActive) {
                    handler.postDelayed(() -> startListening(), delay);
                }
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null) {
                    checkForKeywords(matches);
                }
                // Restart immediately
                if (isActive) {
                    handler.postDelayed(() -> startListening(), RESTART_DELAY_MS);
                }
            }

            @Override
            public void onPartialResults(Bundle partialResults) {
                ArrayList<String> partial = partialResults.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION);
                if (partial != null && !partial.isEmpty()) {
                    String text = partial.get(0).toLowerCase(Locale.UK);
                    if (callback != null) callback.onPartialResult(text);

                    // Quick check on partial for responsiveness
                    if (isListeningForHotword && containsWakeWord(text)) {
                        Log.d(TAG, "Hotword detected (partial): " + text);
                        if (callback != null) {
                            handler.post(() -> callback.onHotwordDetected());
                        }
                    }
                }
            }

            @Override
            public void onEvent(int eventType, Bundle params) {}
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.UK.toString());
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        // Short speech timeout — hotword detection doesn't need long utterances
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L);
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L);

        try {
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            Log.e(TAG, "Failed to start listening: " + e.getMessage());
            handler.postDelayed(this::startListening, ERROR_RESTART_MS);
        }
    }

    private void checkForKeywords(List<String> results) {
        for (String result : results) {
            String lower = result.toLowerCase(Locale.UK);

            if (isListeningForHotword) {
                if (containsWakeWord(lower)) {
                    Log.d(TAG, "Hotword detected: " + lower);
                    if (callback != null) callback.onHotwordDetected();
                    return;
                }
            } else {
                // In active mode, watch for sleep commands
                if (containsSleepWord(lower)) {
                    Log.d(TAG, "Sleep command detected: " + lower);
                    if (callback != null) callback.onSleepDetected();
                    return;
                }
            }
        }
    }

    private boolean containsWakeWord(String text) {
        for (String wake : WAKE_WORDS) {
            if (text.contains(wake)) return true;
        }
        // Also check phonetic similarity
        return text.contains("jarvis") || text.contains("davis") ||
               text.contains("travis") || text.contains("harvest");
    }

    private boolean containsSleepWord(String text) {
        for (String sleep : SLEEP_WORDS) {
            if (text.contains(sleep)) return true;
        }
        // Simple variations
        return (text.contains("jarvis") && (
            text.contains("sleep") || text.contains("off") ||
            text.contains("stop") || text.contains("bye") ||
            text.contains("goodnight") || text.contains("shutdown")
        ));
    }

    public boolean isActive() { return isActive; }
}
