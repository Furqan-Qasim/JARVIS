package com.furqan.jarvis;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * BuildModeActivity — JARVIS Holographic 3D Workshop
 *
 * Full-screen landscape 3D modeling environment rendered via Three.js in WebView.
 * Features:
 *  - Infinite dark grid background with glowing blue lines
 *  - Voice-controlled 3D model generation
 *  - Wireframe → Shaded → Rendered modes
 *  - Gesture controls: pinch to scale, drag to rotate, two-finger pan
 *  - Real-time physics commentary from JARVIS (text overlay)
 *  - Export OBJ / STL to Downloads/JARVIS_Models/
 */
public class BuildModeActivity extends AppCompatActivity {

    private static final String TAG = "BuildMode";

    private WebView buildWebView;
    private TextView jarvisCommentary;
    private ImageButton btnExit;
    private ImageButton btnExportObj;
    private ImageButton btnExportStl;
    private ImageButton btnWireframe;
    private ImageButton btnShaded;
    private ImageButton btnPhysics;

    private GeminiLiveManager geminiLive;
    private MemoryManager memory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Landscape full-screen
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        setContentView(R.layout.activity_build_mode);

        memory = MemoryManager.getInstance(this);
        geminiLive = JarvisApp.liveManager;

        buildWebView     = findViewById(R.id.build_webview);
        jarvisCommentary = findViewById(R.id.jarvis_commentary);
        btnExit          = findViewById(R.id.btn_exit_build);
        btnExportObj     = findViewById(R.id.btn_export_obj);
        btnExportStl     = findViewById(R.id.btn_export_stl);
        btnWireframe     = findViewById(R.id.btn_wireframe);
        btnShaded        = findViewById(R.id.btn_shaded);
        btnPhysics       = findViewById(R.id.btn_physics);

        setupBuildWebView();
        setupBuildButtons();
        showCommentary("Build Mode initialised, sir. What shall we construct today?");
    }

    // ─── WebView Setup ────────────────────────────────────────────────────

    private void setupBuildWebView() {
        WebSettings ws = buildWebView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(false);

        buildWebView.addJavascriptInterface(new BuildBridge(), "BuildBridge");
        buildWebView.setWebViewClient(new WebViewClient());
        buildWebView.setBackgroundColor(0xFF000000);
        buildWebView.loadUrl("file:///android_asset/buildmode.html");
    }

    /**
     * JavaScript ↔ Java bridge for 3D build mode
     */
    private class BuildBridge {

        @JavascriptInterface
        public void onModelReady(String modelName, int vertexCount, int faceCount) {
            String commentary = String.format(
                "Model '%s' generated — %d vertices, %d faces. " +
                "Structural integrity analysis complete. " +
                "No critical stress points detected at standard load conditions, sir.",
                modelName, vertexCount, faceCount);
            runOnUiThread(() -> showCommentary(commentary));
        }

        @JavascriptInterface
        public void onExportReady(String format, String data) {
            saveExportedModel(format, data);
        }

        @JavascriptInterface
        public void onPhysicsResult(String result) {
            runOnUiThread(() -> showCommentary("Physics analysis: " + result));
        }

        @JavascriptInterface
        public void log(String msg) {
            android.util.Log.d("BuildJS", msg);
        }

        @JavascriptInterface
        public void jarvisComment(String comment) {
            runOnUiThread(() -> showCommentary(comment));
        }

        /** Called when user describes a model — we relay to Gemini for instructions */
        @JavascriptInterface
        public void requestModelFromDescription(String description) {
            // Ask Gemini to generate Three.js geometry instructions
            queryGeminiForModel(description);
        }
    }

    // ─── Buttons ─────────────────────────────────────────────────────────

    private void setupBuildButtons() {
        btnExit.setOnClickListener(v -> {
            showCommentary("Exiting Build Mode. Your work has been saved to the session, sir.");
            finish();
        });

        btnExportObj.setOnClickListener(v -> {
            buildWebView.evaluateJavascript("exportOBJ()", null);
            showCommentary("Exporting OBJ file — standby, sir.");
        });

        btnExportStl.setOnClickListener(v -> {
            buildWebView.evaluateJavascript("exportSTL()", null);
            showCommentary("Exporting STL file for fabrication, sir.");
        });

        btnWireframe.setOnClickListener(v -> {
            buildWebView.evaluateJavascript("setRenderMode('wireframe')", null);
            showCommentary("Switching to wireframe skeleton view.");
        });

        btnShaded.setOnClickListener(v -> {
            buildWebView.evaluateJavascript("setRenderMode('shaded')", null);
            showCommentary("Applying PBR materials and lighting, sir.");
        });

        btnPhysics.setOnClickListener(v -> {
            buildWebView.evaluateJavascript("runPhysicsAnalysis()", null);
            showCommentary("Running structural stress analysis...");
        });
    }

    // ─── Gemini Integration for Model Generation ─────────────────────────

    private void queryGeminiForModel(String description) {
        if (geminiLive == null || !geminiLive.isConnected()) {
            showCommentary("Voice connection offline. Please activate JARVIS first, sir.");
            return;
        }

        String prompt = "[SYSTEM: User wants to build: '" + description + "'. " +
            "Describe how to procedurally generate this as a Three.js geometry " +
            "in one concise sentence of expert commentary, as JARVIS would. " +
            "Then output a single [BUILD: geometry_type | params...] tag with " +
            "the Three.js geometry constructor and key parameters. " +
            "Example: [BUILD: TorusKnotGeometry | p=2 | q=3 | tube=0.4 | tubularSegments=100]]";

        geminiLive.sendText(prompt);
    }

    // ─── Public API: Call from voice commands ─────────────────────────────

    public void buildFromVoice(String description) {
        buildWebView.evaluateJavascript(
            "buildFromDescription('" + escapeJs(description) + "')", null);
        showCommentary("Generating: " + description + " — standby, sir.");
    }

    public void setRenderMode(String mode) {
        buildWebView.evaluateJavascript("setRenderMode('" + mode + "')", null);
    }

    // ─── Export / Save ────────────────────────────────────────────────────

    private void saveExportedModel(String format, String data) {
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS), "JARVIS_Models");
            if (!dir.exists()) dir.mkdirs();

            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss",
                Locale.UK).format(new Date());
            String filename = "jarvis_model_" + timestamp + "." + format.toLowerCase();
            File file = new File(dir, filename);

            FileWriter writer = new FileWriter(file);
            writer.write(data);
            writer.close();

            String path = file.getAbsolutePath();
            runOnUiThread(() -> {
                showCommentary("Model exported successfully, sir.\nSaved to: " + path);
                Toast.makeText(this, "Saved: " + filename, Toast.LENGTH_LONG).show();
            });

        } catch (Exception e) {
            runOnUiThread(() ->
                showCommentary("Export failed, sir. Storage error: " + e.getMessage()));
        }
    }

    // ─── UI Helpers ───────────────────────────────────────────────────────

    private void showCommentary(String text) {
        jarvisCommentary.setText(text);
        jarvisCommentary.setVisibility(View.VISIBLE);
        jarvisCommentary.removeCallbacks(hideCommentaryRunnable);
        jarvisCommentary.postDelayed(hideCommentaryRunnable, 6000);
    }

    private final Runnable hideCommentaryRunnable = () ->
        jarvisCommentary.setVisibility(View.INVISIBLE);

    private String escapeJs(String s) {
        return s.replace("'", "\\'").replace("\n", "\\n");
    }
}
