# JARVIS — Complete AIDE Setup Guide
## Building on your Android phone, start to finish

---

## BEFORE YOU BEGIN — GET YOUR GEMINI API KEY

1. Go to https://aistudio.google.com/apikey on your phone's browser
2. Sign in with your Google account
3. Click "Create API key"
4. Copy the key — you'll paste it into the app's Settings screen when first launched
5. The free tier includes Gemini 1.5 Flash (text mode) and Gemini 2.5 Flash Live (voice)

---

## STEP 1 — INSTALL AIDE

1. Install **AIDE - Android IDE** from the Play Store (the original by appfour GmbH)
2. Grant AIDE storage permissions when prompted
3. Open AIDE → accept all prompts

---

## STEP 2 — CREATE THE PROJECT IN AIDE

1. In AIDE, tap the **folder icon** top-left → "New Project"
2. Select **"Android App"** (NOT "Android Library")
3. Fill in:
   - App Name: `JARVIS`
   - Package Name: `com.furqan.jarvis`
   - Min SDK: `26` (Android 8.0)
   - Target SDK: `34`
4. Tap **Create**

AIDE creates:
```
JARVIS/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/furqan/jarvis/MainActivity.java
│       └── res/
│           ├── layout/activity_main.xml
│           └── values/strings.xml
└── build.gradle
```

---

## STEP 3 — REPLACE ALL FILES

For each file below, navigate to it in AIDE's file tree,
long-press → "Replace" (or delete and create new):

### Files to create/replace:

| File | Action |
|------|--------|
| `build.gradle` (root) | REPLACE |
| `app/build.gradle` | REPLACE |
| `app/src/main/AndroidManifest.xml` | REPLACE |
| `app/src/main/java/com/furqan/jarvis/MainActivity.java` | REPLACE |
| `app/src/main/java/com/furqan/jarvis/JarvisService.java` | CREATE |
| `app/src/main/java/com/furqan/jarvis/GeminiLiveManager.java` | CREATE |
| `app/src/main/java/com/furqan/jarvis/HotwordDetector.java` | CREATE |
| `app/src/main/java/com/furqan/jarvis/JarvisAccessibilityService.java` | CREATE |
| `app/src/main/java/com/furqan/jarvis/FloatingCameraService.java` | CREATE |
| `app/src/main/java/com/furqan/jarvis/DeviceController.java` | CREATE |
| `app/src/main/java/com/furqan/jarvis/MemoryManager.java` | CREATE |
| `app/src/main/java/com/furqan/jarvis/BootReceiver.java` | CREATE |
| `app/src/main/java/com/furqan/jarvis/TextModeActivity.java` | CREATE |
| `app/src/main/java/com/furqan/jarvis/BuildModeActivity.java` | CREATE |
| `app/src/main/java/com/furqan/jarvis/PermissionActivity.java` | CREATE |
| `app/src/main/res/layout/activity_main.xml` | REPLACE |
| `app/src/main/res/layout/activity_text_mode.xml` | CREATE |
| `app/src/main/res/layout/activity_build_mode.xml` | CREATE |
| `app/src/main/res/values/strings.xml` | REPLACE |
| `app/src/main/res/values/colors.xml` | CREATE |
| `app/src/main/res/xml/accessibility_service_config.xml` | CREATE |
| `app/src/main/assets/hologram.html` | CREATE |
| `app/src/main/assets/buildmode.html` | CREATE |

---

## STEP 4 — BUILD THE PROJECT

1. In AIDE, tap the **Run** button (▶) or press the compile icon
2. AIDE will download dependencies (OkHttp, Gson) — allow it
3. First build may take 2-5 minutes on-device
4. If build succeeds, AIDE offers to install — tap YES

---

## STEP 5 — GRANT ALL PERMISSIONS (CRITICAL)

After installing, JARVIS will walk you through permissions via its own UI.
But also do these MANUALLY:

### A. Accessibility Service
Settings → Accessibility → Installed Apps → JARVIS → Enable
*(This allows JARVIS to control other apps)*

### B. Draw Over Other Apps
Settings → Apps → JARVIS → "Display over other apps" → Allow
*(Required for floating camera window and always-on HUD)*

### C. Notification Access
Settings → Notifications → Notification access → JARVIS → Allow
*(Allows JARVIS to read notifications)*

### D. Device Admin (optional, for lock screen)
Settings → Security → Device admin apps → JARVIS → Activate
*(Allows JARVIS to lock/unlock screen)*

### E. All Files Access
Settings → Apps → JARVIS → Permissions → Files → "Allow management of all files"
*(Full filesystem access)*

### F. Autostart / Battery
Settings → Battery → App launch / Autostart → JARVIS → Manual → enable all toggles
*(Prevents Android from killing the background service)*
*(On MIUI/EMUI/One UI this is critical — location varies by OEM)*

---

## STEP 6 — FIRST LAUNCH

1. Open JARVIS
2. On first run, tap the **Settings (⚙)** icon (top right)
3. Paste your Gemini API key
4. Tap "Save & Initialize"
5. JARVIS will greet you: *"Good [morning/afternoon/evening], sir. All systems are operational."*

---

## STEP 7 — USING JARVIS

### Voice Activation
Say: **"Hey Jarvis"** — the hologram activates
Say: **"Jarvis, log off"** — returns to silent background mode

### Text Mode
Tap the **text icon** or say: *"Hey Jarvis, switch to text mode"*

### Build Mode (3D Studio)
Say: *"Hey Jarvis, enter build mode"*
Say: *"Hey Jarvis, exit build mode"* to return

### Camera Mode
Say: *"Hey Jarvis, log onto camera"*

---

## TROUBLESHOOTING

**Build fails with "cannot find symbol"**
→ Check that ALL Java files are in the correct package folder

**WebSocket connection fails**
→ Verify your API key in Settings; check internet connection

**Hotword not detected**
→ Grant microphone permission; check battery optimization exemption

**Service keeps dying**
→ Add JARVIS to battery whitelist; disable battery optimization for it

**App crashes on launch**
→ Ensure minSdk is set to 26 in app/build.gradle

---

## ARCHITECTURE OVERVIEW

```
User Voice → HotwordDetector → JarvisService
                                     ↓
                              GeminiLiveManager (WebSocket)
                                     ↓
                              Gemini 2.5 Flash Live API
                                     ↓
                              Audio Response → AudioTrack
                                     ↓
                    [If action required] → DeviceController
                                               ↓
                                    AccessibilityService → App Control
```

---
*Built for Furqan Qasim's personal Android device*
*Package: com.furqan.jarvis*
